BUHAY Android project (WebView wrapper + web app assets).

GitHub:
- Upload this ZIP to the root of the main branch, OR upload the extracted project files.
- The included .github/workflows/build-apk.yml handles either layout.
- Open GitHub Actions and download the BUHAY-debug-APK artifact.

Important files:
- app/src/main/assets/www/index.html : app UI
- app/src/main/assets/www/live.js : Firebase-backed social features and WebRTC call flow
- app/src/main/assets/www/fbx.js : Firebase Auth / Firestore / Realtime Database layer
- app/src/main/assets/www/firebase-config.js : Firebase project and optional service settings
- firebase/ : Firestore and Realtime Database rules
- BUHAY-KARNE-KE-STEPS.txt : required Firebase / Google setup and limitations

Important limitations:
- Google login needs the Firebase Android app SHA-1/SHA-256 and Web OAuth client ID configured.
- WebRTC audio/video calls are implemented peer-to-peer, but no TURN relay or background FCM call notification is included.
- Firebase features must be tested with two real accounts/devices before being called production-ready.
- The committed debug keystore is for repeatable test builds only, never Play Store release signing.
