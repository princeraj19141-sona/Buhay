// BUHAY AI proxy (Cloudflare Worker). Keeps your Anthropic API key secret and only lets logged-in BUHAY users call it.
// Secrets to add in Cloudflare (Settings > Variables and Secrets):
//   ANTHROPIC_API_KEY  = your key from console.anthropic.com
//   FIREBASE_API_KEY   = the apiKey from firebase-config.js
// Optional variables: MODEL (default claude-haiku-5-5), ALLOW_ORIGIN (default https://appassets.androidplatform.net)
const hits = new Map(); // best-effort rate limit per user (resets when the worker restarts)

export default {
  async fetch(req, env) {
    const origin = req.headers.get('Origin') || '';
    const allow = (env.ALLOW_ORIGIN || 'https://appassets.androidplatform.net').split(',').map(s => s.trim());
    const cors = {
      'Access-Control-Allow-Origin': allow.includes(origin) ? origin : allow[0],
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Vary': 'Origin'
    };
    const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
    if (!env.ANTHROPIC_API_KEY || !env.FIREBASE_API_KEY) return json({ error: 'Worker is not configured' }, 500);

    // 1. only signed-in BUHAY users
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer /, '');
    if (!token) return json({ error: 'Login required' }, 401);
    const v = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + env.FIREBASE_API_KEY, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ idToken: token })
    });
    if (!v.ok) return json({ error: 'Invalid login' }, 401);
    const uid = ((await v.json()).users || [])[0]?.localId;
    if (!uid) return json({ error: 'Invalid login' }, 401);

    // 2. simple rate limit: 20 requests per minute per user
    const now = Date.now(), arr = (hits.get(uid) || []).filter(t => now - t < 60000);
    if (arr.length >= 20) return json({ error: 'Too many requests, slow down' }, 429);
    arr.push(now); hits.set(uid, arr);

    // 3. clean the input
    let body; try { body = await req.json(); } catch (e) { return json({ error: 'Bad request' }, 400); }
    const system = String(body.system || '').slice(0, 1500);
    const msgs = [];
    for (const m of (Array.isArray(body.messages) ? body.messages : []).slice(-12)) {
      const role = m.role === 'assistant' ? 'assistant' : 'user';
      const content = String(m.content || '').slice(0, 2000).trim();
      if (!content) continue;
      if (msgs.length && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += '\n' + content;
      else msgs.push({ role, content });
    }
    while (msgs.length && msgs[0].role !== 'user') msgs.shift();
    if (!msgs.length) return json({ error: 'Nothing to answer' }, 400);

    // 4. ask Claude
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: env.MODEL || 'claude-haiku-5-5', max_tokens: Math.min(Number(body.max_tokens) || 300, 500), system, messages: msgs })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return json({ error: (j.error && j.error.message) || 'AI request failed' }, 502);
    const text = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('').trim();
    return json({ text: text || '…' });
  }
};
