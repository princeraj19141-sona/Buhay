package com.buhay.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_HOST + "/assets/www/index.html";

    private static final int REQ_FILE = 101;
    private static final int REQ_CAMERA = 102;
    private static final int REQ_PERM_CAMERA_CHOOSER = 201;
    private static final int REQ_PERM_WEB = 202;

    private FrameLayout root;
    private WebView webView;
    private CredentialManager credentialManager;
    private final Handler main = new Handler(Looper.getMainLooper());

    // File chooser state (photo/video/document pickers used by <input type="file">)
    private ValueCallback<Uri[]> fileCallback;
    private WebChromeClient.FileChooserParams pendingParams;
    private Uri cameraUri;

    // Web permission (getUserMedia: camera / microphone) state
    private PermissionRequest pendingWebPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        credentialManager = CredentialManager.create(this);
        WebView.setWebContentsDebuggingEnabled(false);

        setupEdgeToEdge();

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0C0820);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new GoogleAuthBridge(), "AndroidGoogleAuth");
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                }
                fileCallback = callback;
                pendingParams = params;
                boolean wantsImage = false;
                String[] acc = params.getAcceptTypes();
                if (acc != null && acc.length > 0 && acc[0] != null && acc[0].startsWith("image")) {
                    wantsImage = true;
                }
                if (params.isCaptureEnabled() && wantsImage) launchCamera();
                else launchPicker();
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme) && APP_HOST.equalsIgnoreCase(uri.getHost())
                        && uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    return false;
                }
                // Keep third-party pages out of the WebView so the native JS bridge is never exposed to them.
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)
                        || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // The WebView renderer crashed or was killed by Android (low memory). Rebuild the page
                // instead of crashing the whole app.
                main.post(() -> {
                    if (webView != null) webView.loadUrl(START_URL);
                });
                return true;
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (savedInstanceState == null) {
            webView.loadUrl(START_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    /* ---------------- window insets (status bar, nav bar, keyboard) ---------------- */

    private void setupEdgeToEdge() {
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0C0820);
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                return WindowInsets.CONSUMED;
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                return insets.consumeSystemWindowInsets();
            }
        });
    }

    private void applyBars(final boolean lightTheme, final String bgColor) {
        runOnUiThread(() -> {
            try {
                int c = Color.parseColor(bgColor);
                root.setBackgroundColor(c);
                if (webView != null) webView.setBackgroundColor(c);
            } catch (Exception ignored) {}
            Window w = getWindow();
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController ic = w.getInsetsController();
                if (ic != null) {
                    int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    ic.setSystemBarsAppearance(lightTheme ? mask : 0, mask);
                }
            } else {
                int f = w.getDecorView().getSystemUiVisibility();
                if (lightTheme) {
                    f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                } else {
                    f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    if (Build.VERSION.SDK_INT >= 26) f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                w.getDecorView().setSystemUiVisibility(f);
            }
        });
    }

    /* ---------------- file chooser (gallery / documents / camera) ---------------- */

    private void launchPicker() {
        try {
            Intent i = pendingParams != null
                    ? pendingParams.createIntent()
                    : new Intent(Intent.ACTION_GET_CONTENT).setType("*/*");
            startActivityForResult(i, REQ_FILE);
        } catch (Exception e) {
            finishFileChooser(null);
        }
    }

    private void launchCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM_CAMERA_CHOOSER);
            return;
        }
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File f = File.createTempFile("IMG_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            it.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            it.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(it, REQ_CAMERA);
        } catch (Exception e) {
            // No camera app available: fall back to the normal picker.
            launchPicker();
        }
    }

    private void finishFileChooser(Uri[] result) {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
        pendingParams = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            Uri[] r = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            finishFileChooser(resultCode == RESULT_OK ? r : null);
        } else if (requestCode == REQ_CAMERA) {
            if (resultCode == RESULT_OK && cameraUri != null) finishFileChooser(new Uri[]{cameraUri});
            else finishFileChooser(null);
            cameraUri = null;
        }
    }

    /* ---------------- camera / microphone for the web page ---------------- */

    private void handleWebPermission(PermissionRequest request) {
        Uri origin = request.getOrigin();
        if (origin == null || !APP_HOST.equalsIgnoreCase(origin.getHost())) {
            request.deny();
            return;
        }
        List<String> need = new ArrayList<>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (need.isEmpty()) {
            grantAllowed(request);
        } else {
            if (pendingWebPerm != null) pendingWebPerm.deny();
            pendingWebPerm = request;
            requestPermissions(need.toArray(new String[0]), REQ_PERM_WEB);
        }
    }

    private void grantAllowed(PermissionRequest request) {
        List<String> ok = new ArrayList<>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(res);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(res);
            }
        }
        if (ok.isEmpty()) request.deny();
        else request.grant(ok.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERM_CAMERA_CHOOSER) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) launchCamera();
            else launchPicker(); // user said no to the camera: let them pick from the gallery instead
        } else if (requestCode == REQ_PERM_WEB) {
            if (pendingWebPerm != null) {
                grantAllowed(pendingWebPerm);
                pendingWebPerm = null;
            }
        }
    }

    /* ---------------- JS bridges ---------------- */

    private class NativeBridge {
        /** Save a file (data is base64) into Downloads/BUHAY. Result comes back via window.__buhaySaved(ok, message). */
        @JavascriptInterface
        public void saveFile(final String filename, final String mime, final String base64) {
            new Thread(() -> {
                try {
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    String safe = (filename == null ? "buhay-file" : filename).replaceAll("[^A-Za-z0-9._-]", "_");
                    String where;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BUHAY");
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (u == null) throw new Exception("Could not create file");
                        try (OutputStream os = getContentResolver().openOutputStream(u)) {
                            if (os == null) throw new Exception("Could not open file");
                            os.write(data);
                        }
                        where = "Downloads/BUHAY/" + safe;
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        if (dir == null) dir = getFilesDir();
                        File f = new File(dir, safe);
                        try (FileOutputStream os = new FileOutputStream(f)) {
                            os.write(data);
                        }
                        where = "Android/data/" + getPackageName() + "/files/Download/" + safe;
                    }
                    callJs("window.__buhaySaved&&window.__buhaySaved(true," + JSONObject.quote(where) + ")");
                } catch (Exception e) {
                    callJs("window.__buhaySaved&&window.__buhaySaved(false,"
                            + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                }
            }).start();
        }

        /** Open the Android share sheet with some text (and optional link). */
        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Share"));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("BUHAY", text));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
            });
        }

        /** Make the status/navigation bar icons dark (light theme) or light (dark theme) and set the background. */
        @JavascriptInterface
        public void setBars(boolean lightTheme, String bgColor) {
            applyBars(lightTheme, bgColor);
        }

        @JavascriptInterface
        public boolean isApp() {
            return true;
        }
    }

    private void callJs(final String js) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private class GoogleAuthBridge {
        /** clientId = Web OAuth client ID. Empty string = use default_web_client_id from strings.xml. */
        @JavascriptInterface
        public void signIn(final String clientId) {
            runOnUiThread(() -> launchGoogleCredentialPicker(clientId));
        }
    }

    private void launchGoogleCredentialPicker(String jsClientId) {
        String clientId = (jsClientId != null && jsClientId.endsWith(".apps.googleusercontent.com"))
                ? jsClientId : getString(R.string.default_web_client_id);
        if (clientId.startsWith("REPLACE_") || !clientId.endsWith(".apps.googleusercontent.com")) {
            sendGoogleResult(null, "Google sign-in setup is incomplete. The Web OAuth client ID must be added (see BUHAY-KARNE-KE-STEPS.txt).");
            return;
        }

        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(clientId).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(option)
                .build();

        credentialManager.getCredentialAsync(
                this,
                request,
                null,
                command -> main.post(command),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse result) {
                        Credential credential = result.getCredential();
                        if (credential instanceof CustomCredential
                                && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                            try {
                                GoogleIdTokenCredential google = GoogleIdTokenCredential.createFrom(
                                        ((CustomCredential) credential).getData());
                                sendGoogleResult(google.getIdToken(), null);
                            } catch (Exception e) {
                                sendGoogleResult(null, "Could not read the Google account credential.");
                            }
                        } else {
                            sendGoogleResult(null, "Google did not return a supported sign-in credential.");
                        }
                    }

                    @Override
                    public void onError(@NonNull GetCredentialException e) {
                        String message;
                        if (e instanceof GetCredentialCancellationException) {
                            message = "Google sign-in was cancelled.";
                        } else if (e instanceof NoCredentialException) {
                            message = "No Google account found on this phone, or this app's SHA-1 / Web client ID is not set up in Firebase.";
                        } else {
                            message = e.getMessage() == null ? "Google sign-in is unavailable." : e.getMessage();
                        }
                        sendGoogleResult(null, message);
                    }
                }
        );
    }

    private void sendGoogleResult(String idToken, String error) {
        if (webView == null || isFinishing()) return;
        String tokenArg = idToken == null ? "null" : JSONObject.quote(idToken);
        String errorArg = error == null ? "null" : JSONObject.quote(error);
        callJs("window.__buhayGoogleResult && window.__buhayGoogleResult(" + tokenArg + "," + errorArg + ");");
    }

    /* ---------------- lifecycle / back button ---------------- */

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        // Ask the web app first: it closes sheets / dialogs / stories / chat and returns true if it handled the press.
        webView.evaluateJavascript(
                "(function(){try{return window.__buhayBack?window.__buhayBack():false}catch(e){return false}})()",
                value -> {
                    if (!"true".equals(value)) finish();
                });
    }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidGoogleAuth");
            webView.removeJavascriptInterface("AndroidBridge");
            ViewGroup parent = (ViewGroup) webView.getParent();
            if (parent != null) parent.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
