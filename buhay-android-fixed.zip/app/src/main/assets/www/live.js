/* BUHAY live layer: replaces demo behaviour with real Firebase / device features.
   Loaded after the main script in index.html. */
(function(){
'use strict';
const CX=window.BUHAY_FIREBASE||{};
const NAT=window.AndroidBridge||null;

/* ============ platform helpers (work in demo mode too) ============ */
const b64=blob=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]||'');r.onerror=()=>rej(r.error);r.readAsDataURL(blob)});
window.saveBlob=async function(name,blob){
  try{
    if(NAT&&NAT.saveFile){
      const data=await b64(blob);
      return await new Promise(res=>{
        const to=setTimeout(()=>{delete window.__buhaySaved;toast('Save timed out');res(false)},30000);
        window.__buhaySaved=(ok,msg)=>{clearTimeout(to);delete window.__buhaySaved;toast(ok?'Saved: '+msg:'Could not save: '+msg);res(ok)};
        NAT.saveFile(name,blob.type||'application/octet-stream',data);
      });
    }
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();
    setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},2000);toast('Downloaded');return true;
  }catch(e){toast('Could not save the file');return false}
};
window.nativeShare=function(text,url){
  const t=url?text+'\n'+url:text;
  if(NAT&&NAT.share){NAT.share(t);return}
  if(navigator.share){navigator.share({text,url}).catch(()=>{});return}
  try{navigator.clipboard.writeText(t);toast('Copied to clipboard')}catch(e){toast('Sharing is not available')}
};
window.copyText=function(t){if(NAT&&NAT.copy){NAT.copy(t);return}try{navigator.clipboard.writeText(t)}catch(e){}};
/* status / navigation bar colours follow the theme */
const THEME_BG={dark:'#0c0820',light:'#eee8ff',love:'#ffeef6'};
function syncBars(){if(!NAT||!NAT.setBars)return;const t=document.documentElement.dataset.theme||'dark';try{NAT.setBars(t!=='dark',THEME_BG[t]||THEME_BG.dark)}catch(e){}}
new MutationObserver(syncBars).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});syncBars();
/* Android back button */
window.__buhayBack=function(){
  const vis=s=>{const n=$(s);return n&&!n.hidden};
  if(vis('#lb')){$('#lb').hidden=true;return true}
  if(vis('#sht')){closeSheet();return true}
  if(vis('#call'))return true;
  if(vis('#sv')){closeS();return true}
  if(vis('#dl')){$('#dl').hidden=true;return true}
  if(vis('#cs')){$('#csx').click();return true}
  if(CUR==='chat'){if(selMode){endSel();return true}if(vis('#emo')){$('#emo').hidden=true;return true}if(vis('#csb')){$('#csx2').click();return true}$('#cbk').click();return true}
  if(CUR==='user'){go(PV&&PV!=='user'?PV:'home');return true}
  if(['photo','editor','design','camera'].includes(CUR)){go('create');return true}
  if(CUR==='signup'){go('login');return true}
  if(CUR==='login'){go('welcome');return true}
  if(AU.includes(CUR))return false;
  if(CUR!=='home'){go('home');return true}
  return false;
};
/* the service worker is pointless inside the APK (assets are local) and can serve stale pages */
if(NAT&&navigator.serviceWorker){navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister())).catch(()=>{})}
addEventListener('offline',()=>toast('You are offline'));addEventListener('online',()=>toast('Back online'));

if(typeof FBON==='undefined'||!FBON)return;   // everything below needs Firebase (live mode)

/* ============ live mode ============ */
document.documentElement.classList.add('live');
const L={uid:null,posts:[],reels:[],stories:[],follow:new Set(),followers:new Set(),req:new Set(),reqIn:[],loaded:{posts:false,reels:false},byUid:{},cmUn:null,rcId:null,rcUn:null,storyN:{}};
window.L=L;
const SK={posts:'pl',reels:'rl'};
let rrLive=()=>{};
function fillTags(n,t){(t||'').split(/(#\w+)/).forEach(x=>{if(/^#\w+$/.test(x)){const s=el('span','ht',x);s.dataset.tag=x.slice(1);n.appendChild(s)}else if(x)n.appendChild(document.createTextNode(x))})}
const URLOK=s=>typeof s==='string'&&(/^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(s)||/^https:\/\/[^\s"'()<>\\]+$/.test(s));
const bgu=(n,src)=>{n.style.backgroundImage=URLOK(src)?'url("'+src+'")':''};
const canSee=uid=>uid===L.uid||!(uInfo(uid)&&uInfo(uid).priv)||L.follow.has(uid);
const uidKey=uid=>uid===L.uid?'__me':(RTM.peers&&RTM.peers[uid])||null;
const uInfo=uid=>L.byUid[uid]||null;
const uName=(uid,fallback)=>uid===L.uid?PF.name:(uInfo(uid)?uInfo(uid).n:(fallback||'User'));
const uAv=uid=>uid===L.uid?MD.avatar:(uInfo(uid)?uInfo(uid).av:'');
const keyUid=k=>k==='__me'?L.uid:(USERS[k]&&USERS[k].uid)||null;
function paintAv(n,uid){if(!n)return;const s=uAv(uid);if(URLOK(s)){n.style.backgroundImage='url("'+s+'")';n.textContent='';n.classList.add('im')}}
function avEl(uid,name){const n=el('i','a '+A[hue(uid||name||'x')%4],(name||'U')[0].toUpperCase());n.dataset.uid=uid||'';paintAv(n,uid);return n}
/* paint avatars of any avatar circle created by the older code */
new MutationObserver(ms=>{ms.forEach(m=>m.addedNodes.forEach(nd=>{if(nd.nodeType!==1)return;const list=nd.classList&&nd.classList.contains('a')?[nd]:[];$$('.a',nd).forEach(x=>list.push(x));list.forEach(n=>{
  if(n.classList.contains('i-me')||n.style.backgroundImage)return;let uid=n.dataset.uid;
  if(!uid){const u=n.dataset.u||(n.closest('[data-u]')||{dataset:{}}).dataset.u;if(u)uid=keyUid(u);}
  if(!uid){const r=n.closest('[data-ch]');if(r){const c=CH.find(x=>x.id===r.dataset.ch);if(c&&c.uid)uid=c.uid}}
  if(uid)paintAv(n,uid)})}))}).observe(document.body,{childList:true,subtree:true});
const noPics=s=>{const x=document.createElement('style');x.textContent=s;document.head.appendChild(x)};
noPics('html.live .a.i-me{background-image:none}');

/* ---------- uploads (Cloudinary, optional) and AI helper ---------- */
const CL=CX.cloudinary&&CX.cloudinary.cloud&&CX.cloudinary.preset?CX.cloudinary:null;
async function cloudUp(file,type){
  if(!CL)throw new Error('Cloudinary is not set up');
  const fd=new FormData();fd.append('file',file);fd.append('upload_preset',CL.preset);
  const r=await fetch('https://api.cloudinary.com/v1_1/'+CL.cloud+'/'+type+'/upload',{method:'POST',body:fd});
  const j=await r.json().catch(()=>({}));
  if(!r.ok||!j.secure_url)throw new Error((j.error&&j.error.message)||'Upload failed');
  return j.secure_url;
}
const hostImg=async d=>{if(!d)return '';if(CL){try{return await cloudUp(d,'image')}catch(e){}}return d};
async function aiAsk(system,messages,max){
  if(!CX.aiEndpoint)throw new Error('noai');
  const tok=await FBX.idToken();
  const r=await fetch(CX.aiEndpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+tok},body:JSON.stringify({system,messages,max_tokens:max||300})});
  const j=await r.json().catch(()=>({}));
  if(!r.ok||!j.text)throw new Error(j.error||'AI request failed');
  return j.text;
}
window.aiAsk=aiAsk;

/* ---------- persist private state (liked/saved/blocked/settings) ---------- */
let pT=null;
window.livePersist=function(){if(!L.uid||!L.ready)return;clearTimeout(pT);pT=setTimeout(()=>{FBX.setState(L.uid,{pl:ST.pl,rl:ST.rl,bm:ST.bm,bu:ST.bu,saved:ST.saved,cfg:CFG,theme:document.documentElement.dataset.theme||'dark'}).catch(()=>{})},600)};
window.liveSaveMedia=function(){if(!L.uid||!L.ready)return;
  FBX.profile(L.uid,{av:MD.avatar||''}).catch(()=>toast('Could not save your photo'));
  FBX.setCover(L.uid,MD.cover||'').catch(()=>toast('Could not save your cover photo'))};

/* ---------- users (override: keeps avatar/site/location) ---------- */
rtUsers=function(arr){const seen={};L.byUid={};
  arr.forEach(x=>{let k=x.name||x.username;if(USERS[k]&&USERS[k].uid!==x.uid)k=k+' (@'+x.username+')';
    USERS[k]={h:x.username,b:x.bio||'',f:'—',c:x.loc||'',n:x.name||x.username,uid:x.uid,av:x.av||'',site:x.site||'',priv:!!x.priv,ms:x.createdMs||0};
    seen[x.uid]=k;L.byUid[x.uid]=USERS[k]});
  Object.keys(USERS).forEach(k=>{if(!Object.values(seen).includes(k))delete USERS[k]});
  RTM.peers=seen;CH.forEach(c=>{if(c.rt&&c.type!=='group'&&seen[c.uid])c.name=seen[c.uid]});
  rcl();if(CURCH&&CUR==='chat')renderThread(true);
  if(L.ready){rfeed();rrLive();mas('all',$('#sq').value);rst();renderProfile();if(CUR==='user')renderUser()}};

/* ---------- boot after login ---------- */
const _rtBoot=rtBoot;
rtBoot=async function(u){
  const had=RTM.on&&RTM.uid===u.uid;
  await _rtBoot(u);
  if(had||!RTM.on||RTM.uid!==u.uid||L.uid===u.uid)return;
  L.uid=u.uid;
  const st=await FBX.getState(u.uid);
  ST.pl=st.pl||[];ST.rl=st.rl||[];ST.bm=st.bm||[];ST.bu=st.bu||[];ST.saved=st.saved||[];ST.fol=[];
  const rr0=CFG.rr,on0=CFG.online;if(st.cfg)Object.assign(CFG,st.cfg);CFG.rr=rr0;CFG.online=on0;CFG.priv=(RTM.me&&RTM.me.privacy&&RTM.me.privacy.priv)?1:0;
  if(st.theme)document.documentElement.dataset.theme=st.theme;
  MD.avatar=(RTM.me&&RTM.me.av)||'';MD.gal=[];MD.cover=await FBX.getCover(u.uid);
  PF.site=(RTM.me&&RTM.me.site)||'';PF.loc=(RTM.me&&RTM.me.loc)||'';PF.created=(RTM.me&&RTM.me.createdMs)||0;
  L.ready=true;applyCfg();renderProfile();
  RTM.unsubs.push(
    FBX.watchPosts('posts',rows=>{L.posts=rows;L.loaded.posts=true;rfeed();mas('all',$('#sq').value);renderProfile();if(CUR==='user')renderUser()}),
    FBX.watchPosts('reels',rows=>{L.reels=rows;L.loaded.reels=true;rrLive();renderProfile()}),
    FBX.watchStories(rows=>{L.stories=rows;rst()}),
    FBX.watchFollows(u.uid,(ing,ers,ro,ri)=>{L.follow=new Set(ing);L.followers=new Set(ers);L.req=new Set(ro);L.reqIn=ri;refreshFollowUI()}),
    FBX.watchIncoming(u.uid,onIncoming));
};

/* ---------- feed ---------- */
function tagText(t){const p=el('p','');t.split(/(#\w+)/).forEach(s=>{if(/^#\w+$/.test(s)){const x=el('span','ht',s);x.dataset.tag=s.slice(1);p.appendChild(x)}else if(s)p.appendChild(document.createTextNode(s))});return p}
function findRow(kind,id){return (kind==='reels'?L.reels:L.posts).find(x=>x.id===id)}
function actsEl(p,kind){
  const a=el('div','acts');a.dataset.id=p.id;a.dataset.kind=kind;const mk=(act,ic,txt,aria)=>{const b=el('button','');b.dataset.act=act;b.setAttribute('aria-label',aria);b.appendChild(icn(ic));if(txt!=null)b.appendChild(el('span','',txt));a.appendChild(b);return b};
  mk('like','heart',fm(p.lk||0),'Like');mk('cm','chat',fm(p.cc||0),'Comments');mk('sh','send',null,'Share');
  const sp=el('span');sp.style.flex='1';a.appendChild(sp);
  if(p.by===L.uid)mk('del','trash',null,'Delete post').classList.add('lv-del');
  mk('bm','bookmark',null,'Save post').classList.add('lv-bm');
  setActs(a,p);return a}
function setActs(a,p){const kind=a.dataset.kind,lk=ST[SK[kind]].includes(p.id),b=$('[data-act=like]',a);b.classList.toggle('on',lk);$('span',b).textContent=fm(Math.max(0,p.lk||0));$('[data-act=cm] span',a).textContent=fm(p.cc||0);$('[data-act=bm]',a).classList.toggle('on',ST.bm.includes(p.id))}
function postEl(p,kind){
  const mine=p.by===L.uid,a=el('article','post card');a.dataset.pid=p.id;a.dataset.kind=kind;
  const ph=el('div','ph');ph.dataset.u=uidKey(p.by)||'';ph.appendChild(avEl(p.by,uName(p.by,p.name)));
  const d=el('div');d.appendChild(el('b','',uName(p.by,p.name)));d.appendChild(el('small','',ago(p.ts)));ph.appendChild(d);a.appendChild(ph);
  if(p.text)a.appendChild(tagText(p.text));
  const src=p.img||p.url;if(src&&URLOK(src)){if(p.mk==='video'){const v=document.createElement('video');v.className='pimg';v.src=src;v.controls=true;v.playsInline=true;v.preload='metadata';a.appendChild(v)}else{const i=document.createElement('img');i.className='pimg';i.src=src;i.alt='Post photo';i.loading='lazy';a.appendChild(i)}}
  a.appendChild(actsEl(p,kind));return a}
function reconcile(box,items,make,upd){
  [...box.children].forEach(n=>{if(!n.dataset||!n.dataset.pid)n.remove()});
  const old=new Map([...box.children].map(n=>[n.dataset.pid,n])),out=[];
  items.forEach(it=>{let n=old.get(it.id);if(n){upd(n,it);old.delete(it.id)}else n=make(it);out.push(n)});
  old.forEach(n=>n.remove());out.forEach((n,i)=>{if(box.children[i]!==n)box.insertBefore(n,box.children[i]||null)})}
rfeed=function(){
  const box=$('#feed');if(!box)return;
  if(!L.loaded.posts){if(!$('.sk',box))box.innerHTML='<div class="card sk"></div><div class="card sk"></div>';return}
  let ps=L.posts.filter(p=>!ST.bu.includes(p.by)&&canSee(p.by));
  if(FTAB.v==='fl')ps=ps.filter(p=>L.follow.has(p.by)||p.by===L.uid);
  if(FTAB.v==='tr')ps=[...ps].sort((a,b)=>((b.lk||0)-(a.lk||0))||(b.ts-a.ts));
  if(!ps.length){box.innerHTML='';const e=el('div','card emp');e.appendChild(el('b','',FTAB.v==='fl'?'Nothing from people you follow yet':'No posts yet'));e.appendChild(el('p','mu',FTAB.v==='fl'?'Follow people from Discover or Reels.':'Be the first: share something above.'));box.appendChild(e);return}
  reconcile(box,ps,p=>postEl(p,'posts'),(n,p)=>{setActs($('.acts',n),p);const b=$('.ph b',n);if(b)b.textContent=uName(p.by,p.name);paintAv($('.ph .a',n),p.by)})};
skel=function(){$('#feed').innerHTML='<div class="card sk"></div><div class="card sk"></div>';setTimeout(rfeed,300)};
$('#live').innerHTML='';
$('#cp').onsubmit=async e=>{e.preventDefault();const text=$('#ci').value.trim();if(!text&&!PIMG){toast('Write something or add a photo');return}
  const img0=PIMG;$('#ci').value='';PIMG='';$('#cpp').hidden=true;toast('Posting…');
  try{const img=await hostImg(img0);await FBX.addPost('posts',L.uid,PF.name,{text,img});toast('Posted')}
  catch(x){toast('Could not post: '+(x.code||x.message));$('#ci').value=text}};

/* like / comment / share / save / delete (feed, explore sheet, profile sheet) */
async function toggleLike(kind,id){
  const k=SK[kind],had=ST[k].includes(id),row=findRow(kind,id);if(!row)return;
  ST[k]=had?ST[k].filter(x=>x!==id):[...ST[k],id];row.lk=Math.max(0,(row.lk||0)+(had?-1:1));
  $$('.acts[data-id="'+id+'"]').forEach(a=>setActs(a,row));
  try{await FBX.like(kind,id,L.uid,!had);livePersist();
    if(row.by!==L.uid){if(!had)FBX.notify('lk_'+id+'_'+L.uid,{to:row.by,from:L.uid,fromName:PF.name,type:'like',ref:id,kind}).catch(()=>{});else FBX.unnotify('lk_'+id+'_'+L.uid).catch(()=>{})}}
  catch(e){ST[k]=had?[...ST[k],id]:ST[k].filter(x=>x!==id);row.lk=Math.max(0,(row.lk||0)+(had?1:-1));$$('.acts[data-id="'+id+'"]').forEach(a=>setActs(a,row));
    if(e.code==='permission-denied'&&!had){if(!ST[k].includes(id))ST[k].push(id);livePersist();toast('Already liked')}else toast('Could not update like')}}
function lvShare(row,kind){nativeShare((row.text?row.text.slice(0,120)+' — ':'')+'by '+uName(row.by,row.name)+' on BUHAY'+(CX.shareUrl?'':''),CX.shareUrl||'')}
function delRow(kind,id){sheet(b=>{head(b,'Delete this '+(kind==='reels'?'reel':'post')+'?');item(b,'trash','Delete',()=>{FBX.delPost(kind,id).then(()=>toast('Deleted')).catch(()=>toast('Could not delete'))},'dg');item(b,'x','Cancel',()=>{})})}
document.addEventListener('click',e=>{
  const b=e.target.closest('.acts [data-act]');if(!b)return;const a=b.closest('.acts'),id=a.dataset.id,kind=a.dataset.kind,row=findRow(kind,id);if(!row)return;
  const act=b.dataset.act;
  if(act==='like')toggleLike(kind,id);
  else if(act==='cm')openComments(kind,id);
  else if(act==='sh')lvShare(row,kind);
  else if(act==='bm'){const on=!ST.bm.includes(id);ST.bm=on?[...ST.bm,id]:ST.bm.filter(x=>x!==id);$$('.acts[data-id="'+id+'"]').forEach(x=>setActs(x,row));livePersist();toast(on?'Saved':'Removed from saved')}
  else if(act==='del')delRow(kind,id)});
$('#home').addEventListener('dblclick',e=>{const p=e.target.closest('.pimg');if(!p)return;const a=$('.acts',p.closest('article'));if(a&&!ST.pl.includes(a.dataset.id))toggleLike(a.dataset.kind,a.dataset.id)});
document.addEventListener('click',e=>{const t=e.target.closest('.ht');if(!t||t.closest('#rf'))return;go('explore');$('#sq').value='#'+t.dataset.tag;exSearch('#'+t.dataset.tag)});

/* comments (bottom sheet for posts) */
function commentRow(c,kind,pid,ownerUid,box){
  const r=el('div','cm');r.appendChild(avEl(c.by,uName(c.by,c.name)));
  const d=el('div'),n=el('b','',uName(c.by,c.name));n.dataset.u=uidKey(c.by)||'';d.appendChild(n);d.appendChild(el('small','mu',' · '+ago(c.ts)));d.appendChild(el('br'));d.appendChild(el('span','',c.text));r.appendChild(d);
  if(c.by===L.uid||ownerUid===L.uid){const x=el('button','',null);x.setAttribute('aria-label','Delete comment');x.appendChild(icn('trash'));x.style.cssText='margin-left:auto;color:#ff4d6d;align-self:center';x.onclick=()=>FBX.delComment(kind,pid,c.id).catch(()=>toast('Could not delete'));r.appendChild(x)}
  box.appendChild(r)}
function openComments(kind,id){
  const row=findRow(kind,id);if(!row)return;if(L.cmUn){L.cmUn();L.cmUn=null}
  sheet(b=>{head(b,'Comments');const l=el('div');l.style.cssText='display:flex;flex-direction:column;gap:10px;padding:4px 6px 10px;max-height:44dvh;overflow:auto';b.appendChild(l);
    L.cmUn=FBX.watchComments(kind,id,rows=>{l.innerHTML='';if(!rows.length)l.appendChild(el('p','mu','No comments yet. Say something nice.'));rows.forEach(c=>commentRow(c,kind,id,row.by,l));l.scrollTop=l.scrollHeight});
    const f=el('form','send'),i=el('input');i.placeholder='Add a comment…';i.maxLength=300;i.setAttribute('aria-label','Add a comment');const fl=el('label','fld');fl.style.flex='1';fl.appendChild(i);f.appendChild(fl);const sb=el('button','btn','Post');sb.style.padding='10px 16px';f.appendChild(sb);
    f.onsubmit=async ev=>{ev.preventDefault();const v=i.value.trim();if(!v)return;i.value='';
      try{const cid=await FBX.addComment(kind,id,L.uid,PF.name,v);if(row.by!==L.uid)FBX.notify('cm_'+cid,{to:row.by,from:L.uid,fromName:PF.name,type:'comment',ref:id,kind,text:v.slice(0,80)}).catch(()=>{})}catch(x){toast('Could not comment');i.value=v}};
    b.appendChild(f)})}
const _closeSheet=closeSheet;closeSheet=function(){if(L.cmUn){L.cmUn();L.cmUn=null}_closeSheet()};

/* ---------- post / media detail sheet (Explore + profile grids) ---------- */
function mediaSheet2(kind,p){sheet(b=>{
  const src=p.img||p.url;if(src&&URLOK(src)){let m;if(p.mk==='video'){m=document.createElement('video');m.src=src;m.controls=true;m.playsInline=true}else{m=document.createElement('img');m.src=src;m.alt='Photo'}m.style.cssText='width:100%;max-height:50dvh;object-fit:contain;border-radius:14px;background:#000';b.appendChild(m)}
  const h=el('div','ph');h.style.padding='8px 4px';h.dataset.u=uidKey(p.by)||'';h.appendChild(avEl(p.by,uName(p.by,p.name)));const d=el('div');d.appendChild(el('b','',uName(p.by,p.name)));d.appendChild(el('small','',ago(p.ts)));h.appendChild(d);b.appendChild(h);
  if(p.text)b.appendChild(tagText(p.text)).style.padding='0 6px 8px';
  b.appendChild(actsEl(p,kind));
  if(src&&p.mk!=='video'&&URLOK(src))item(b,'sliders','Edit in Photo Editor',()=>openEd(src))})}
document.addEventListener('click',e=>{const a=e.target.closest('.acts[data-kind] [data-act]');if(a&&a.closest('#shb')&&a.dataset.act==='del')closeSheet()},true);

/* ---------- Discover ---------- */
{const m=$('#mas');m.replaceWith(m.cloneNode(false))}
$('#xc').innerHTML='<button class="tab on" data-c="all">All</button><button class="tab" data-c="tr">Trending</button><button class="tab" data-c="fol">Following</button><button class="tab" data-c="sv">Saved</button>';
const tileH=id=>150+([...id].reduce((s,c)=>s+c.charCodeAt(0),0)%120);
mas=function(c,q){c=c||'all';q=(q||'').trim().toLowerCase().replace(/^#/,'');
  let ps=L.posts.filter(p=>(p.img||p.url)&&!ST.bu.includes(p.by)&&canSee(p.by));
  if(c==='fol')ps=ps.filter(p=>L.follow.has(p.by));if(c==='sv')ps=ps.filter(p=>ST.bm.includes(p.id));if(c==='tr')ps=[...ps].sort((a,b)=>(b.lk||0)-(a.lk||0));
  if(q)ps=ps.filter(p=>(p.text||'').toLowerCase().includes(q)||uName(p.by,p.name).toLowerCase().includes(q));
  const box=$('#mas');box.innerHTML='';
  if(!ps.length){box.appendChild(el('p','mu',L.loaded.posts?(q?'No results. Try another word.':'No photos yet. Post one from Home or Create.'):'Loading…'));return}
  ps.forEach(p=>{const t=el('div','mt im');t.dataset.pid=p.id;t.style.height=tileH(p.id)+'px';bgu(t,p.img||p.url);t.appendChild(el('span','',(p.text||uName(p.by,p.name)).slice(0,30)));
    const s=el('span','mtb');s.setAttribute('role','button');s.setAttribute('aria-label','Save');s.dataset.sv=p.id;s.classList.toggle('on',ST.bm.includes(p.id));s.appendChild(icn('heart'));t.appendChild(s);box.appendChild(t)})};
$('#mas').addEventListener('click',e=>{const s=e.target.closest('[data-sv]');
  if(s){e.stopPropagation();const id=s.dataset.sv,on=!ST.bm.includes(id);ST.bm=on?[...ST.bm,id]:ST.bm.filter(x=>x!==id);s.classList.toggle('on',on);livePersist();toast(on?'Saved':'Removed');return}
  const t=e.target.closest('.mt');if(!t)return;const p=findRow('posts',t.dataset.pid);if(p)mediaSheet2('posts',p)});
exSearch=function(q){q=(q||'').trim();const qq=q.replace(/^#/,'').toLowerCase(),xp=$('#xp'),xr=$('#xr');xp.innerHTML='';xr.innerHTML='';
  const tab=($('#xc .tab.on')||{dataset:{c:'all'}}).dataset.c;
  if(!q){const cnt={};[...L.posts,...L.reels].forEach(p=>(p.text||'').match(/#\w+/g)?.forEach(t=>{t=t.slice(1).toLowerCase();cnt[t]=(cnt[t]||0)+1}));
    const tags=Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]).slice(0,8);
    if(tags.length){xr.appendChild(el('small','mu','Trending'));tags.forEach(t=>{const b=el('button');b.appendChild(icn('hash'));b.appendChild(document.createTextNode(t));b.onclick=()=>{$('#sq').value='#'+t;exSearch('#'+t)};xr.appendChild(b)})}
    if(RCN.length){xr.appendChild(el('small','mu','Recent'));RCN.slice(0,5).forEach(t=>{const b=el('button',null,t);b.onclick=()=>{$('#sq').value=t;exSearch(t)};xr.appendChild(b)})}
    mas(tab,'');return}
  Object.keys(USERS).filter(n=>n.toLowerCase().includes(qq)||(USERS[n].h||'').includes(qq)).slice(0,12).forEach(n=>{const b=el('button');b.dataset.u=n;b.appendChild(avEl(USERS[n].uid,USERS[n].n||n));b.appendChild(el('span','',(USERS[n].n||n).split(' ')[0]));xp.appendChild(b)});
  mas(tab,qq)};
$('#sq').onfocus=()=>{if(!$('#sq').value)exSearch('')};
exSearch('');

/* ---------- Reels ---------- */
function reelEl(r){
  const lk=ST.rl.includes(r.id),v=el('div','rv im');v.dataset.rid=r.id;
  const src=r.url||r.img;
  if(r.mk==='video'&&URLOK(src)){const vd=document.createElement('video');vd.src=src;vd.muted=REELMUTE;vd.loop=true;vd.playsInline=true;vd.preload='metadata';vd.className='rvid';v.appendChild(vd)}else bgu(v,src);
  const mine=r.by===L.uid,key=uidKey(r.by)||'';
  v.insertAdjacentHTML('beforeend','<div class="ra"><button class="rb" data-a="lk" aria-label="Like">'+IC('heart')+'<span></span></button><button data-a="cm" aria-label="Comments">'+IC('chat')+'<span></span></button><button data-a="sh" aria-label="Share">'+IC('send')+'<span>Share</span></button><button class="bk" data-a="sv" aria-label="Save">'+IC('bookmark')+'<span>Save</span></button>'+(mine?'<button data-a="del" aria-label="Delete reel">'+IC('trash')+'<span>Delete</span></button>':'')+'</div><div class="rm"><i class="a"></i><b></b><button class="fo" data-a="fo"></button></div><div class="rc"></div><div class="rs2">'+IC('music')+'<span>Original audio</span></div><span class="pzi">'+IC('play')+'</span><div class="rp"><i></i></div>');
  const av=$('.rm .a',v);av.dataset.u=key;av.dataset.uid=r.by;av.className='a '+A[hue(r.by)%4];av.textContent=uName(r.by,r.name)[0].toUpperCase();paintAv(av,r.by);
  const nm=$('.rm b',v);nm.dataset.u=key;nm.textContent=uName(r.by,r.name);
  const fo=$('.fo',v);if(mine)fo.remove();else{fo.dataset.h=r.by}
  fillTags($('.rc',v),r.text||'');
  reelCounts(v,r);return v}
function reelCounts(v,r){const lk=ST.rl.includes(r.id);const b=$('[data-a=lk]',v);b.classList.toggle('on',lk);$('span',b).textContent=fm(Math.max(0,r.lk||0));$('[data-a=cm] span',v).textContent=fm(r.cc||0);$('[data-a=sv]',v).classList.toggle('on',ST.bm.includes(r.id));const fo=$('.fo',v);if(fo){const on=L.follow.has(fo.dataset.h),rq=L.req.has(fo.dataset.h);fo.classList.toggle('on',on||rq);fo.textContent=on?'Following':rq?'Requested':'Follow'}}
rrLive=function(){const rf=$('#rf');if(!rf)return;
  if(!L.loaded.reels){rf.innerHTML='<div class="rv" style="align-items:center;justify-content:center;text-align:center">Loading…</div>';return}
  let rs=L.reels.filter(r=>!ST.bu.includes(r.by)&&canSee(r.by));if(RT==='fol')rs=rs.filter(r=>L.follow.has(r.by)||r.by===L.uid);
  [...rf.children].forEach(n=>{if(!n.dataset.rid)n.remove()});
  if(!rs.length){rf.innerHTML='<div class="rv" style="align-items:center;justify-content:center;text-align:center;cursor:default;padding:30px">'+(RT==='fol'?'Follow creators to see their reels here.':'No reels yet. Tap + to share the first one.')+'</div>';return}
  const old=new Map([...rf.children].map(n=>[n.dataset.rid,n])),out=[];
  rs.forEach(r=>{let n=old.get(r.id);if(n){reelCounts(n,r);old.delete(r.id)}else{n=reelEl(r);io.observe(n)}out.push(n)});
  old.forEach(n=>{io.unobserve(n);n.remove()});out.forEach((n,i)=>{if(rf.children[i]!==n)rf.insertBefore(n,rf.children[i]||null)})};
const _rrOld=rr;rr=function(){rrLive()};
$('.rt').onclick=e=>{const b=e.target.closest('button');if(!b)return;RT=b.dataset.t;$$('.rt button').forEach(x=>x.classList.toggle('on',x===b));$('#rf').innerHTML='';rrLive()};
async function reelLike(v){const id=v.dataset.rid;await toggleLike('reels',id);const r=findRow('reels',id);if(r)reelCounts(v,r)}
$('#rf').addEventListener('click',e=>{const v=e.target.closest('.rv');if(!v||!v.dataset.rid)return;if(e.target.closest('[data-tag],.rc'))return;
  const id=v.dataset.rid,r=findRow('reels',id),b=e.target.closest('button');
  if(e.target.closest('[data-u]'))return;
  if(b){const a=b.dataset.a;
    if(a==='lk')reelLike(v);
    else if(a==='cm')openReelComments(id);
    else if(a==='sh'&&r)lvShare(r,'reels');
    else if(a==='sv'){const on=!ST.bm.includes(id);ST.bm=on?[...ST.bm,id]:ST.bm.filter(x=>x!==id);if(r)reelCounts(v,r);livePersist();toast(on?'Saved':'Removed from saved')}
    else if(a==='del')delRow('reels',id);
    else if(a==='fo'){const h=b.dataset.h;followToggle(h)}
    return}
  if(e.detail>1){clearTimeout(pt);if(!ST.rl.includes(id))reelLike(v);v.insertAdjacentHTML('beforeend',IC('heart').replace('class="ic"','class="ic hb"'));setTimeout(()=>$('.hb',v)?.remove(),700);return}
  clearTimeout(pt);pt=setTimeout(()=>{v.classList.toggle('pz');const vd=$('.rvid',v);if(vd)v.classList.contains('pz')?vd.pause():vd.play().catch(()=>{})},230)});
function openReelComments(id){const row=findRow('reels',id);if(!row)return;L.rcId=id;if(L.rcUn)L.rcUn();$('#cst').textContent='Comments';$('#cs').hidden=false;document.body.classList.add('cmo');
  L.rcUn=FBX.watchComments('reels',id,rows=>{const l=$('#cls');l.innerHTML='';if(!rows.length)l.appendChild(el('p','mu','No comments yet.'));rows.forEach(c=>commentRow(c,'reels',id,row.by,l));l.scrollTop=l.scrollHeight})}
$('#csx').onclick=()=>{$('#cs').hidden=true;document.body.classList.remove('cmo');if(L.rcUn){L.rcUn();L.rcUn=null}};
$('#cf').onsubmit=async e=>{e.preventDefault();const v=$('#cin').value.trim(),id=L.rcId,row=findRow('reels',id);if(!v||!row)return;$('#cin').value='';
  try{const cid=await FBX.addComment('reels',id,L.uid,PF.name,v);if(row.by!==L.uid)FBX.notify('cm_'+cid,{to:row.by,from:L.uid,fromName:PF.name,type:'comment',ref:id,kind:'reels',text:v.slice(0,80)}).catch(()=>{})}catch(x){toast('Could not comment');$('#cin').value=v}};
/* follow / unfollow */
function refreshFollowUI(){rrLive();rfeed();mas('all',$('#sq').value);rst();if(CUR==='user')renderUser();renderProfile();const n=$('#sfreqn');if(n)n.textContent=L.reqIn.length||''}
async function followToggle(uid){if(!uid||uid===L.uid)return;
  const following=L.follow.has(uid),requested=L.req.has(uid),priv=!!(uInfo(uid)&&uInfo(uid).priv);
  const undo=()=>{L.follow.delete(uid);L.req.delete(uid);if(following)L.follow.add(uid);if(requested)L.req.add(uid);refreshFollowUI()};
  if(following||requested){L.follow.delete(uid);L.req.delete(uid);refreshFollowUI();
    try{await FBX.unfollow(L.uid,uid);FBX.unnotify('fo_'+L.uid+'_'+uid).catch(()=>{});toast(requested?'Request cancelled':'Unfollowed')}catch(e){undo();toast('Could not update follow')}return}
  if(priv)L.req.add(uid);else L.follow.add(uid);refreshFollowUI();
  try{await FBX.follow(L.uid,uid,priv);FBX.notify('fo_'+L.uid+'_'+uid,{to:uid,from:L.uid,fromName:PF.name,type:priv?'freq':'follow'}).catch(()=>{});toast(priv?'Follow request sent':'Following')}
  catch(e){undo();toast('Could not follow. Try again.')}}
/* upload reel */
$('#rup').onclick=()=>sheet(b=>{head(b,'Create reel');const inp=document.createElement('input');inp.type='file';inp.accept=CL?'video/*,image/*':'image/*';let file=null;
  const pv=el('div','mu','No file chosen');pv.style.padding='4px 10px 8px';const pick=item(b,'upload',CL?'Choose video or photo':'Choose photo',()=>{});pick.onclick=()=>inp.click();b.appendChild(pv);
  if(!CL){const n=el('p','mu','Video upload needs Cloudinary to be set up (see BUHAY-KARNE-KE-STEPS.txt). Photos work now.');n.style.cssText='padding:0 10px 8px;font-size:12px';b.appendChild(n)}
  inp.onchange=()=>{file=inp.files[0]||null;pv.textContent=file?file.name:'No file chosen'};
  const f=el('label','fld2'),ci=el('input');ci.placeholder='Write a caption…';ci.maxLength=300;ci.setAttribute('aria-label','Caption');f.appendChild(ci);b.appendChild(f);
  const go2=el('button','btn','Share reel');go2.style.margin='8px 4px 0';
  go2.onclick=async()=>{if(!file){toast('Choose a file first');return}const cap=ci.value.trim();go2.disabled=true;toast('Uploading…');
    try{let o;if(file.type.startsWith('video/')){if(!CL){toast('Video upload needs Cloudinary');go2.disabled=false;return}if(file.size>100*1048576){toast('Video is too large (max 100 MB)');go2.disabled=false;return}o={mk:'video',url:await cloudUp(file,'video')}}
      else o={mk:'img',img:await hostImg(await fileToMax(file,900))};
      await FBX.addPost('reels',L.uid,PF.name,{text:cap,...o});closeSheet();RT='all';$$('.rt button').forEach(x=>x.classList.toggle('on',x.dataset.t==='all'));toast('Reel shared')}
    catch(x){toast('Upload failed: '+(x.message||x.code));go2.disabled=false}};b.appendChild(go2)});

/* ---------- Stories ---------- */
function storyGroups(){const g={};L.stories.filter(s=>!ST.bu.includes(s.by)&&canSee(s.by)).forEach(s=>{(g[s.by]=g[s.by]||[]).push(s)});return g}
const liveSlides=function(n){const g=storyGroups(),uid=n==='You'?L.uid:keyUid(n);return (g[uid]||[]).sort((a,b)=>a.ts-b.ts)};
rst=function(){const bx=$('#stories');if(!bx)return;bx.innerHTML='';const g=storyGroups();MS=(g[L.uid]||[]).sort((a,b)=>a.ts-b.ts);
  const me=el('div','st');me.dataset.n='You';const r=el('div','ring'+(MS.length?(SV.has('You')?' seen':''):' none'));const av=el('div','a im i-me '+(MD.avatar?'':A[hue(PF.name||'U')%4]),MD.avatar?'':(PF.name||'U')[0].toUpperCase());if(MD.avatar)bgu(av,MD.avatar);r.appendChild(av);const pl=el('span','plb');pl.dataset.add='1';pl.appendChild(icn('plus'));r.appendChild(pl);me.appendChild(r);me.appendChild(document.createTextNode('Your story'));bx.appendChild(me);
  Object.keys(g).filter(u=>u!==L.uid).sort((a,b)=>g[b][g[b].length-1].ts-g[a][g[a].length-1].ts).forEach(uid=>{const key=uidKey(uid);if(!key)return;const s=el('div','st');s.dataset.n=key;const rg=el('div','ring'+(g[uid].every(x=>SV.has(x.id))?' seen':''));rg.appendChild(avEl(uid,uName(uid)));s.appendChild(rg);s.appendChild(document.createTextNode(uName(uid).split(' ')[0]));bx.appendChild(s)})};
sshow=function(){clearTimeout(sTm);const s=SC.sl[SC.i];if(!s)return;$('#pbs').innerHTML=SC.sl.map((_,i)=>'<i class="'+(i<SC.i?'d':i===SC.i?'c':'')+'"><b></b></i>').join('');
  const v=$('#svi'),t=$('#svtx');t.hidden=true;v.style.background='';v.style.backgroundImage='';
  if(s.src){v.className='svi im';bgu(v,s.src)}else if(s.txt){v.className='svi';v.style.background=s.bg||'#222';t.textContent=s.txt;t.hidden=false}else v.className='svi im';
  $('#svt2').textContent=ago(s.ts);$('#svl').classList.remove('on');
  if(SC.n==='You')FBX.storyViews(s.id).then(c=>{if(SC.sl[SC.i]===s)$('#svt2').textContent=ago(s.ts)+' · '+c+' view'+(c===1?'':'s')});
  else FBX.viewStory(s.id,L.uid).catch(()=>{});
  SV.add(s.id);LS.s('sviewed',[...SV]);sTm=setTimeout(()=>sstep(1),5000)};
openStory=function(n){const sl=liveSlides(n);if(!sl.length)return;SC={n,i:0,sl};const uid=n==='You'?L.uid:keyUid(n),a=$('#sva');
  a.className='a '+A[hue(uid||'x')%4];a.style.backgroundImage='';a.textContent=uName(uid)[0].toUpperCase();a.dataset.u=n==='You'?'__me':n;paintAv(a,uid);
  $('#svn').textContent=uName(uid);$('#svn').dataset.u=a.dataset.u;$('#svm').hidden=n!=='You';$('#svr').hidden=n==='You';SV.add('You');$('#sv').hidden=false;sshow();rst()};
addSlide=async function(s){try{toast('Adding to your story…');const o=s.src?{src:await hostImg(s.src)}:{txt:s.txt,bg:s.bg};await FBX.addStory(L.uid,PF.name,o);toast('Added to your story',()=>openStory('You'))}catch(e){toast('Could not add story: '+(e.code||e.message))}};
$('#svm').onclick=()=>{clearTimeout(sTm);const s=SC.sl[SC.i];sheet(b=>{head(b,'Delete this story?');item(b,'trash','Delete',()=>{FBX.delStory(s.id).then(()=>{toast('Story deleted');closeS()}).catch(()=>toast('Could not delete'))},'dg');item(b,'x','Cancel',()=>{sshow()})})};
$('#svl').onclick=e=>{const on=e.currentTarget.classList.toggle('on');const s=SC.sl[SC.i];if(on&&s&&s.by!==L.uid){FBX.notify('sl_'+s.id+'_'+L.uid,{to:s.by,from:L.uid,fromName:PF.name,type:'like',ref:s.id,kind:'story'}).catch(()=>{});toast('Liked')}};
$('#svr').onsubmit=e=>{e.preventDefault();const v=$('#svri').value.trim();if(!v)return;$('#svri').value='';const n=SC.n;closeS();const id=dmFor(n);if(id==='ai')return;CURCH=id;post({t:'↩️ Story: '+v});toast('Reply sent',()=>openChat(id))};
rst();

/* ---------- Profile (me) ---------- */
const myRows=k=>(k==='reels'?L.reels:L.posts).filter(p=>p.by===L.uid);
function metaLine(m,loc,site){m.innerHTML='';[['pin',loc],['link',site]].forEach(([i,t])=>{if(!t)return;const s=document.createElement('span');s.innerHTML=IC(i)+'<i></i>';$('i',s).textContent=t;m.appendChild(s)})}
function tilesGrid(rows,box,empty){
  if(!rows.length){box.innerHTML='';box.appendChild(el('p','mu',empty)).style.cssText='padding:22px;text-align:center';return}
  const g=el('div','pg3');rows.forEach(r=>{const d=el('div','im');d.dataset.pid=r.id;d.dataset.kind=r._k;const src=r.img||r.url;
    if(src&&r.mk!=='video'&&URLOK(src))bgu(d,src);else{d.style.cssText='display:grid;place-items:center;text-align:center;padding:6px;font-size:12px;overflow:hidden';d.textContent=r.mk==='video'?'▶ Video':(r.text||'').slice(0,60)}g.appendChild(d)});
  box.innerHTML='';box.appendChild(g)}
prt=function(){const c=$('#pc');
  if(PT==='about'){c.innerHTML='<div class="abt"><div>'+IC('user')+'<span></span></div><div>'+IC('pin')+'<span></span></div><div>'+IC('link')+'<span></span></div><div>'+IC('spark')+'<span></span></div></div>';const s=$$('span',c);
    s[0].textContent=PF.name+' (@'+PF.user+')';s[1].textContent=PF.loc||'Location not set';s[2].textContent=PF.site||'No website yet';s[3].textContent=PF.created?'Member since '+new Date(PF.created).toLocaleDateString([], {month:'long',year:'numeric'}):'Member of BUHAY';return}
  let rows=[];
  if(PT==='posts')rows=myRows('posts').map(r=>({...r,_k:'posts'}));
  else if(PT==='reels')rows=myRows('reels').map(r=>({...r,_k:'reels'}));
  else rows=[...L.posts.map(r=>({...r,_k:'posts'})),...L.reels.map(r=>({...r,_k:'reels'}))].filter(r=>ST.bm.includes(r.id));
  tilesGrid(rows,c,PT==='saved'?'Nothing saved yet. Tap the bookmark on a post.':PT==='reels'?'No reels yet.':'No posts yet. Share your first one from Home.')};
$('#pc').onclick=e=>{const d=e.target.closest('[data-pid]');if(!d)return;const r=findRow(d.dataset.kind,d.dataset.pid);if(r)mediaSheet2(d.dataset.kind,r)};
renderProfile=function(){
  $('#pn').textContent=PF.name||'';$('#pu').textContent='@'+(PF.user||'');$('#pb').textContent=PF.bio||'';metaLine($('#pm'),PF.loc,PF.site);
  $$('.a.i-me').forEach(e=>{A.forEach(c=>e.classList.remove(c));if(MD.avatar){bgu(e,MD.avatar);e.textContent=''}else{e.style.backgroundImage='';e.classList.add(A[hue(PF.name||'U')%4]);e.textContent=(PF.name||'U')[0].toUpperCase()}});
  bgu($('#pcv'),MD.cover);
  $('#pcn').textContent=myRows('posts').length+myRows('reels').length;
  const b=$$('#me .stats>div b');if(b[1])b[1].textContent=fm(L.followers.size);if(b[2])b[2].textContent=fm(L.follow.size);
  prt()};
{const s=$('#me .stats');s.replaceWith(s.cloneNode(true))}
$('#me .stats').addEventListener('click',e=>{const d=e.target.closest('.stats>div');if(!d)return;const i=[...d.parentNode.children].indexOf(d);if(i===0)return;
  const uids=[...(i===1?L.followers:L.follow)].filter(u=>uidKey(u));
  sheet(b=>{head(b,i===1?'Followers':'Following');if(!uids.length){b.appendChild(el('p','mu',i===1?'No followers yet.':"You aren't following anyone yet.")).style.padding='14px';return}
    uids.forEach(u=>{const x=el('button','si');x.appendChild(avEl(u,uName(u)));x.appendChild(el('span','',uName(u)));x.appendChild(el('small','',L.follow.has(u)?'Following':''));x.onclick=()=>{closeSheet();openUser(uidKey(u))};b.appendChild(x)})})});
$('#df').addEventListener('submit',()=>setTimeout(()=>{if(L.uid&&PF.name)FBX.profile(L.uid,{name:PF.name,bio:PF.bio||'',site:PF.site||'',loc:PF.loc||''}).catch(()=>toast('Could not save to the server'))},0));
$('#psh').onclick=()=>nativeShare('Find me on BUHAY: '+PF.name+' (@'+PF.user+')',CX.shareUrl||'');

/* ---------- other people's profiles ---------- */
openUser=function(n){if(n==='You')n='__me';if(n==='__me'){go('me');return}if(!USERS[n]){toast('That profile is not available');return}if(CUR!=='user')PV=CUR;UCUR=n;renderUser();go('user')};
ubtn=function(){const uid=keyUid(UCUR),on=L.follow.has(uid),rq=L.req.has(uid),b=$('#ufo');b.textContent=on?'Following':rq?'Requested':'Follow';b.classList.toggle('ghost',on||rq)};
renderUser=function(){const n=UCUR,u=USERS[n];if(!u){go(PV||'home');return}const uid=u.uid,av=$('#uav');
  $('#un').textContent=u.n||n;$('#uh').textContent='@'+u.h;$('#ub').textContent=u.b||'';metaLine($('#um'),u.c,u.site);
  av.className='a '+A[hue(uid)%4];av.style.backgroundImage='';av.textContent=(u.n||n)[0].toUpperCase();paintAv(av,uid);
  $('#ucv').style.backgroundImage='';FBX.getCover(uid).then(s=>{if(UCUR===n)bgu($('#ucv'),s)});
  const rows=[...L.posts.filter(p=>p.by===uid).map(r=>({...r,_k:'posts'})),...L.reels.filter(p=>p.by===uid).map(r=>({...r,_k:'reels'}))].sort((a,b)=>b.ts-a.ts);
  const vis=canSee(uid);tilesGrid(vis?rows:[],$('#ug'),vis?'No posts yet.':'🔒 This account is private. Follow to see their posts.');$('#upc').textContent=vis?rows.length:'–';$('#uf').textContent='…';
  const t3=$$('#user .stats>div b')[2];if(t3)t3.textContent='…';
  FBX.followCounts(uid).then(c=>{if(UCUR!==n)return;$('#uf').textContent=fm(c.followers);if(t3)t3.textContent=fm(c.following)});ubtn()};
$('#ug').addEventListener('click',e=>{const d=e.target.closest('[data-pid]');if(!d)return;const r=findRow(d.dataset.kind,d.dataset.pid);if(r)mediaSheet2(d.dataset.kind,r)});
$('#ufo').onclick=async()=>{await followToggle(keyUid(UCUR));setTimeout(()=>{if(CUR==='user')renderUser()},900)};
$('#umsg').onclick=()=>{const id=dmFor(UCUR);if(id!=='ai')openChat(id)};
function blockUid(uid,on){ST.bu=on?[...new Set([...ST.bu,uid])]:ST.bu.filter(x=>x!==uid);const c=CH.find(x=>x.id==='u:'+uid);if(c){c.blk=on?1:0;save()}livePersist();rfeed();rrLive();rst();mas('all','');rcl()}
$('#umore').onclick=()=>sheet(b=>{const uid=keyUid(UCUR),nm=(USERS[UCUR]||{}).n||UCUR;head(b,nm);item(b,'send','Share profile',()=>nativeShare('Find '+nm+' on BUHAY',CX.shareUrl||''));
  const bl=ST.bu.includes(uid);item(b,'block',bl?'Unblock':'Block',()=>{blockUid(uid,!bl);toast(bl?'Unblocked':nm+' blocked')},'dg');
  item(b,'flag','Report',()=>sheet(b2=>{head(b2,'Report '+nm);['Spam or scam','Harassment','Inappropriate content','Impersonation','Something else'].forEach(r=>item(b2,'flag',r,()=>FBX.report(L.uid,uid,r).then(()=>toast('Thanks, your report was sent.')).catch(()=>toast('Could not send the report'))))}),'dg')});
blockedSheet=function(){sheet(b=>{head(b,'Blocked accounts');const us=ST.bu.filter(Boolean);if(!us.length){b.appendChild(el('p','mu','You have not blocked anyone.')).style.padding='14px';return}
  us.forEach(u=>{const x=el('div','si');x.appendChild(avEl(u,uName(u)));x.appendChild(el('span','',uName(u)));const un=el('button','tagx','Unblock');un.onclick=()=>{blockUid(u,false);blockedSheet()};x.appendChild(un);b.appendChild(x)})})};
$('#sbl').onclick=blockedSheet;

/* ---------- private account: follow requests ---------- */
function reqSheet(){sheet(b=>{head(b,'Follow requests');const us=L.reqIn.filter(u=>uInfo(u));
  if(!us.length){b.appendChild(el('p','mu','No pending requests.')).style.padding='14px';return}
  us.forEach(u=>{const x=el('div','si');x.appendChild(avEl(u,uName(u)));x.appendChild(el('span','',uName(u)));
    const ok=el('button','tagx','Confirm'),no=el('button','tagx','Delete');
    ok.onclick=()=>FBX.approve(L.uid,u).then(()=>{FBX.notify('fa_'+u+'_'+L.uid,{to:u,from:L.uid,fromName:PF.name,type:'facc'}).catch(()=>{});toast('Accepted');x.remove()}).catch(()=>toast('Could not accept'));
    no.onclick=()=>FBX.declineReq(L.uid,u).then(()=>{toast('Request deleted');x.remove()}).catch(()=>toast('Could not delete'));
    x.appendChild(ok);x.appendChild(no);b.appendChild(x)})})}
{const pr=$('[data-cf=priv]');if(pr){const r=el('button','sl');r.id='sfreq';r.appendChild(icn('users'));r.appendChild(document.createTextNode(' Follow requests'));const n=el('span','tagx');n.id='sfreqn';n.style.marginLeft='auto';r.appendChild(n);pr.after(r);r.onclick=reqSheet}}
document.addEventListener('click',e=>{if(!e.target.closest('[data-cf=priv]'))return;setTimeout(()=>{FBX.privacy(L.uid,{read:CFG.rr?1:0,online:CFG.online?1:0,priv:CFG.priv?1:0}).then(()=>toast(CFG.priv?'Your account is now private':'Your account is now public')).catch(()=>toast('Could not update privacy'))},0)});

/* ---------- Notifications ---------- */
const NTXT={like:'liked your post',comment:'commented',follow:'started following you',freq:'requested to follow you',facc:'accepted your follow request',message:'sent you a message'};
let nSeen=null;
rtNotifs=function(arr){
  const fresh=nSeen?arr.filter(n=>!nSeen.has(n.id)&&!n.read&&n.type!=='message'&&Date.now()-(n.ts||0)<60000):[];nSeen=new Set(arr.map(n=>n.id));
  NT.length=0;
  arr.sort((a,b)=>b.ts-a.ts).forEach(n=>{
    const k={like:'likes',comment:'comments',follow:'follows',freq:'follows',facc:'follows',message:'messages'}[n.type]||'system';
    if((k==='likes'&&!CFG.nl)||(k==='comments'&&!CFG.nc)||(k==='follows'&&!CFG.nf))return;
    let t=NTXT[n.type]||'sent you a notification';if(n.type==='like'&&n.kind==='reels')t='liked your reel';if(n.type==='like'&&n.kind==='story')t='liked your story';if(n.type==='comment')t='commented: “'+(n.text||'')+'”';
    const key=uidKey(n.from);
    NT.push({id:'r'+n.id,rid:n.id,k,u:(key&&USERS[key]?USERS[key].n:n.fromName)||'Someone',fromUid:n.from,t,ago:ago(n.ts||Date.now()),to:n.type==='message'?'chat:u:'+n.from:n.type==='freq'?'freqs':(n.type==='follow'||n.type==='facc')?'user:'+n.from:(n.kind==='reels'?'reels':'post:'+n.ref+':'+(n.kind||'posts')) });
    if(n.read)NR.add('r'+n.id)});
  nl();nbadge();
  if(CFG.nm!==0&&fresh.length){const n=fresh[0];toast((n.fromName||'Someone')+' '+(n.type==='comment'?'commented on your post':NTXT[n.type]||'sent a notification'))}};
const _nl=nl;nl=function(){_nl();$$('#nl .nt2').forEach(r=>{const x=NT.find(y=>y.id===r.dataset.n);if(x&&x.fromUid)paintAv($('.a',r),x.fromUid)})};
$('#nl').addEventListener('click',e=>{const r=e.target.closest('.nt2');if(!r)return;const x=NT.find(y=>y.id===r.dataset.n);if(!x||!x.to)return;
  if(x.to.startsWith('post:')){const [,id,kind]=x.to.split(':');const row=findRow(kind,id);if(row)mediaSheet2(kind,row);else toast('That post is no longer available')}
  else if(x.to==='freqs')reqSheet();
  else if(x.to.startsWith('user:')){const k=uidKey(x.to.slice(5));if(k)openUser(k)}});

/* ---------- auth screens: remove demo-only bits ---------- */
$$('.skp').forEach(x=>x.remove());
$$('[data-soc]').forEach(b=>{if(b.dataset.soc!=='Google')b.remove()});
$$('.asoc').forEach(x=>x.style.justifyContent='center');
$$('#signup .afoot').forEach(p=>{if(/Demo account/.test(p.textContent))p.remove()});
$('#em').placeholder='Email';$('#supw').placeholder='Password (min 8 characters)';
$$('[data-soc=Google]').forEach(b=>{b.textContent='';b.innerHTML='<svg viewBox="0 0 48 48" width="22" height="22"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
  b.onclick=()=>{b.disabled=true;FBX.google().catch(e=>{const m=e.nativeMessage||null;if(m){toast(m);const er=$('#err');if(er&&CUR==='login')er.textContent=m}else fbFail(e)}).finally(()=>{b.disabled=false})}});

/* ---------- settings ---------- */
$$('[data-cf=msgs]').forEach(b=>b.remove());
$$('.card.fbs').forEach(c=>c.remove());
{const dz=$('#srs');dz.lastChild.textContent=' Clear local data on this device'}
const safe=$('#srs').parentNode;
{const b=el('button','sl dgx');b.id='sdel';b.style.border='0';b.appendChild(icn('trash'));b.appendChild(document.createTextNode(' Delete my account'));safe.appendChild(b);$('#srs').style.border='';
 b.onclick=()=>sheet(s=>{head(s,'Delete your account?');const p=el('p','mu','This permanently deletes your profile, posts, reels, stories and follows. Chats you sent stay with the other person. This cannot be undone.');p.style.padding='4px 10px 10px';s.appendChild(p);
  let pw=null;if(FBX.providerId()==='password'){const f=el('label','fld2'),i=el('input');i.type='password';i.placeholder='Enter your password to confirm';i.setAttribute('aria-label','Password');f.appendChild(i);s.appendChild(f);pw=i}
  const go2=el('button','btn','Delete forever');go2.style.cssText='margin:8px 4px 0;background:#e5304f';
  go2.onclick=async()=>{go2.disabled=true;try{await FBX.deleteAccount(L.uid,PF.user,pw&&pw.value);toast('Account deleted');setTimeout(()=>location.reload(),800)}
    catch(e){go2.disabled=false;if(e.code==='app/need-password')toast('Enter your password first');else if(e.code==='auth/requires-recent-login')toast('Please sign out, sign in again, then delete right away.');else if(e.code==='auth/invalid-credential'||e.code==='auth/wrong-password')toast('Wrong password');else toast('Could not delete: '+(e.code||e.message))}};
  s.appendChild(go2);item(s,'x','Cancel',()=>{})})}
$('#sdl').onclick=async()=>{const data={app:'BUHAY',exported:new Date().toISOString(),profile:{name:PF.name,username:PF.user,bio:PF.bio,site:PF.site,location:PF.loc},settings:CFG,
  posts:myRows('posts').map(p=>({text:p.text,time:new Date(p.ts).toISOString(),likes:p.lk})),reels:myRows('reels').map(p=>({text:p.text,time:new Date(p.ts).toISOString()})),saved:ST.bm,
  chats:CH.filter(c=>c.rt||c.id==='ai').map(c=>({name:c.name,type:c.type,messages:c.msgs.filter(m=>m.kind!=='sys').map(m=>({from:m.from,text:pvt(m),time:new Date(m.ts).toISOString()}))}))};
  saveBlob('buhay-data.json',new Blob([JSON.stringify(data,null,2)],{type:'application/json'}))};
$('#sab').onclick=()=>sheet(b=>{head(b,'About BUHAY');const p=el('p','mu','BUHAY v1.1. Accounts, posts, reels, stories, follows, chats, groups, calls and notifications are live and stored in your Firebase project.');p.style.padding='4px 10px 12px';b.appendChild(p)});
{const d=$('#sab small');if(d)d.textContent='v1.1'}

/* ============ chats: groups, files, voice, clear / delete ============ */
const rfx=k=>RF[k]||(RF[k]={});
const meInfo=()=>({uid:RTM.uid,name:PF.name});
rtChats=function(docs){
  const present=new Set();
  docs.forEach(d=>{
    const grp=d.type==='group',o=grp?null:d.members.find(m=>m!==RTM.uid);if(!grp&&!o)return;
    const id=grp?'g:'+d.id:'u:'+o;present.add(id);
    const gone=rfx('gone')[id];if(gone){if((d.updatedAt||0)<=gone)return;delete rfx('gone')[id]}
    let c=CH.find(x=>x.id===id);const nm=grp?d.name:(RTM.peers&&RTM.peers[o])||'User';
    if(!c){c={...mk(id,nm,grp?'group':'dm'),rt:1,av:hue(grp?d.id:o)%4,msgs:[],loaded:0,...(RF.chats[id]||{})};CH.push(c)}
    c.rt=1;c.type=grp?'group':'dm';
    if(grp){c.gid=d.id;c.name=d.name||'Group';c.memberUids=d.members;c.members=d.members.filter(u=>u!==RTM.uid).map(u=>uName(u));c.adminUids=d.admins||[];c.admins=c.adminUids.map(u=>u===RTM.uid?'me':uName(u));c.status=''}
    else{c.uid=o;c.name=nm;c.status=presText(o);c.seenPeer=(d.seen&&d.seen[o])||0}
    c.dis=d.dis||0;
    const viewing=CURCH===id&&CUR==='chat',prev=c.lastAt||0,mine=d.last&&d.last.from===RTM.uid;
    if(!c.loaded&&d.last)c.msgs=[{id:'stub',from:mine?'me':(grp?uName(d.last.from):c.name),t:d.last.text,ts:d.updatedAt||Date.now(),st:mine?'delivered':undefined}];
    c.unread=viewing?0:((d.unread&&d.unread[RTM.uid])||0);
    if(RTM.chatsLoaded&&!viewing&&d.last&&!mine&&d.updatedAt>prev&&!c.mute&&CFG.nm!==0&&!ST.bu.includes(d.last.from))toast((grp?c.name+' · ':'')+uName(d.last.from)+': '+String(d.last.text).slice(0,48),()=>openChat(id));
    c.lastAt=d.updatedAt||0;if(viewing&&c.unread===0&&d.unread&&d.unread[RTM.uid])rtSeen(c)});
  CH=CH.filter(c=>c.type!=='group'||!c.rt||present.has(c.id)||c.loaded===0&&Date.now()-(c.created||0)<20000);
  RTM.chatsLoaded=true;rcl()};
rtMap=function(d,c){const x=d.data({serverTimestamps:'estimate'}),mine=x.from===RTM.uid,ts=fbms(x.at)||Date.now(),grp=c.type==='group';
  const nmOf=u=>u===RTM.uid?'me':(grp?uName(u):c.name);let rx=null;
  if(x.rxs){rx={};Object.entries(x.rxs).forEach(([u,e])=>{rx[nmOf(u)]=e})}
  const rp=x.reply?{id:x.reply.id,from:nmOf(x.reply.from),t:x.reply.t}:null;
  const m={id:d.id,from:nmOf(x.from),t:x.del?'':(x.text||''),ts,st:mine?(d.metadata.hasPendingWrites?'sent':(grp?'delivered':(c.seenPeer&&c.seenPeer>=ts?'read':'delivered'))):undefined,reply:rp,fwd:x.fwd?1:0,kind:x.kind==='sticker'?'sticker':'',img:x.img||'',rxs:rx,del:x.del?1:0,edited:x.edited?1:0,star:RF.star[d.id]?1:0,_rt:1};
  if(!x.del&&x.kind==='voice'&&x.url){m.kind='voice';m.voice={d:x.d||1};m.t='';AUD[d.id]=x.url}
  if(!x.del&&x.kind==='file'&&x.url){m.kind='file';m.file={name:x.fn||'File',size:x.fs||'',url:x.url};m.t=''}
  return m};
rtWatch=function(c){rtUnwatch();const cid=rtCid(c);
  RTM.cw.push(FBX.watchMsgs(cid,docs=>{c.loaded=1;const clr=rfx('clr')[c.id]||0;c.msgs=docs.filter(d=>!RF.hide[d.id]).map(d=>rtMap(d,c)).filter(m=>m.ts>clr&&!ST.bu.includes(m.from==='me'?'':(c.type==='group'?'':c.uid)));
    const open=CURCH===c.id&&CUR==='chat';if(open){c.unread=0;renderThread(true);const ld=docs[docs.length-1];if(ld&&ld.data().from!==RTM.uid&&Date.now()-(c.sa||0)>800){c.sa=Date.now();rtSeen(c)}}rcl()}));
  if(c.type!=='group')RTM.cw.push(FBX.watchTyping(cid,c.uid,t=>{c.typing=t?c.name:null;if(CURCH===c.id&&CUR==='chat')renderThread(true);rcl()}));
  rtSeen(c)};
{const _rt=renderThread;renderThread=function(k){_rt(k);const c=gc();if(c&&c.rt&&c.type!=='group'){const a=$('#cav');a.className='a '+A[(c.av||0)%4];paintAv(a,c.uid);if(!uAv(c.uid))a.textContent=c.name[0]}}}
const _post2=post;
post=function(x){const c=gc();if(!(RTM.on&&c&&c.rt))return _post2(x);if(c.blk)return;
  if(x.kind&&!['sticker','voice','file'].includes(x.kind)){toast('That message type is not available');return}
  const text=x.kind==='sticker'?x.t:(x.t||(x.img?'📷 Photo':x.kind==='voice'?'🎤 Voice message':x.kind==='file'?'📎 '+x.fn:''));if(!text)return;
  const ex={};if(x.kind)ex.kind=x.kind;if(x.fwd)ex.fwd=1;if(x.url)ex.url=x.url;if(x.d)ex.d=x.d;if(x.fn){ex.fn=x.fn;ex.fs=x.fs||''}
  if(RPL){const fu=RPL.from==='me'?RTM.uid:(c.type==='group'?(c.memberUids.find(u=>uName(u)===RPL.from)||RTM.uid):c.uid);ex.reply={id:RPL.id,from:fu,t:String(RPL.t).slice(0,120)};RPL=null;$('#crp').hidden=true}
  c.draft='';
  (async()=>{try{if(x.img)ex.img=await hostImg(x.img);
    if(c.type==='group')await FBX.sendGroup(meInfo(),{id:c.gid,members:c.memberUids},text,ex);else{await FBX.send(meInfo(),c.uid,text,ex);FBX.typing(rtCid(c),RTM.uid,false)}}
  catch(e){fbFail(e)}})()};
/* message-level helpers that need group awareness */
const delChat=c=>{if(c.type==='group'){FBX.groupUpdate(c.gid,{members:c.memberUids.filter(u=>u!==RTM.uid)}).catch(()=>toast('Could not leave the group'))}
  rfx('gone')[c.id]=Date.now();RFsave();CH=CH.filter(x=>x.id!==c.id);if(CURCH===c.id)CURCH=null;rcl()};
const _menuItems=menuItems;
menuItems=function(b,c){if(!c.rt)return _menuItems(b,c);
  item(b,'search','Search in chat',openSearch);item(b,'check2','Select messages',()=>{selMode=true;SEL=new Set();renderThread(true)});
  const st=c.msgs.filter(m=>m.star&&!m.del),md=c.msgs.filter(m=>m.img&&!m.del);
  item(b,'star','Starred messages',()=>starSheet(),'',st.length||'');item(b,'image','Media',()=>mediaSheet(),'',md.length||'');
  tgl(b,'belloff','Mute notifications',c.mute,()=>{c.mute=c.mute?0:1;save();rcl()});
  item(b,'clock','Disappearing messages',()=>disSheet(),'',DISL[c.dis||0]);
  item(b,'brush','Wallpaper',()=>wpSheet());item(b,'download','Export chat',exportChat);
  if(c.type==='dm')tgl(b,'block',c.blk?'Unblock contact':'Block contact',c.blk,()=>{blockUid(c.uid,!c.blk);renderThread(true)});
  item(b,'archive',c.arch?'Unarchive chat':'Archive chat',()=>{c.arch=c.arch?0:1;save();rcl();go('chats')});
  item(b,'trash','Clear chat',()=>{rfx('clr')[c.id]=Date.now();RFsave();c.msgs=[];c.pinMsg=null;renderThread();rcl();save()},'dg');
  item(b,'trash',c.type==='group'?'Exit group':'Delete chat',()=>{delChat(c);go('chats')},'dg')};
const _disSheet=disSheet;
disSheet=function(){const c=gc();if(!c||!c.rt)return _disSheet();
  sheet(b=>{head(b,'Disappearing messages');const n=el('p','mu','Messages are hidden on both phones after this time.');n.style.cssText='padding:0 10px 6px;font-size:12px';b.appendChild(n);
    [0,86400,604800].forEach(v=>item(b,'clock',DISL[v],()=>{FBX.chatSetting(rtCid(c),{dis:v}).then(()=>toast(v?'Messages hide after '+DISL[v]:'Disappearing messages off')).catch(()=>toast('Only a group admin can change this'))},'',(c.dis||0)==v?'✓':''))})};
rowMenu=function(id){const c=CH.find(x=>x.id===id);if(!c)return;sheet(b=>{head(b,c.name);
  item(b,'pinicon',c.pin?'Unpin':'Pin chat',()=>{c.pin=c.pin?0:1;rcl();save()});item(b,'belloff',c.mute?'Unmute':'Mute',()=>{c.mute=c.mute?0:1;rcl();save()});
  item(b,'archive',c.arch?'Unarchive':'Archive',()=>{c.arch=c.arch?0:1;rcl();save()});item(b,'mail',c.unread>0?'Mark as read':'Mark as unread',()=>{c.unread=c.unread>0?0:1;rcl();save()});
  item(b,'trash',c.type==='group'?'Exit group':'Delete chat',()=>{c.rt?delChat(c):(CH=CH.filter(x=>x.id!==id),CURCH===id&&(CURCH=null),rcl(),save())},'dg')})};
const _info=info;
info=function(){const c=gc();if(!(c&&c.rt&&c.type==='group'))return _info();
  const admin=c.adminUids.includes(RTM.uid);
  sheet(b=>{const h0=el('div','sh0');h0.appendChild(el('i','a '+A[(c.av||0)%4],c.name[0]));h0.appendChild(el('b','big',c.name));h0.appendChild(el('small','',c.memberUids.length+' members'));b.appendChild(h0);
    head(b,'Members');
    c.memberUids.forEach(u=>{const x=el('div','si');x.appendChild(avEl(u,uName(u)));x.appendChild(el('span','',u===RTM.uid?'You':uName(u)));
      if(c.adminUids.includes(u))x.appendChild(el('span','tagx','Admin'));
      else if(admin){const r=el('button','tagx','Remove');r.onclick=()=>{FBX.groupUpdate(c.gid,{members:c.memberUids.filter(y=>y!==u)}).then(()=>setTimeout(info,500)).catch(()=>toast('Could not remove'))};x.appendChild(r)}b.appendChild(x)});
    if(admin){const add=Object.keys(USERS).filter(k=>!c.memberUids.includes(USERS[k].uid));
      if(add.length){head(b,'Add members');add.forEach(k=>item(b,'plus',USERS[k].n||k,()=>{FBX.groupUpdate(c.gid,{members:[...c.memberUids,USERS[k].uid]}).then(()=>toast('Added')).catch(()=>toast('Could not add'))}))}
      const rn=el('label','fld2');rn.appendChild(icn('pencil'));const ri=el('input');ri.value=c.name;ri.maxLength=40;ri.setAttribute('aria-label','Group name');rn.appendChild(ri);
      const rb=el('button','tagx','Rename');rb.onclick=()=>{const v=ri.value.trim();if(v)FBX.groupUpdate(c.gid,{name:v}).then(()=>toast('Group renamed')).catch(()=>toast('Could not rename'))};rn.appendChild(rb);b.appendChild(rn)}
    head(b,'Settings');menuItems(b,c)})};
newGroup=function(){sheet(b=>{head(b,'New group');const f=el('label','fld2');f.appendChild(icn('users'));const i=el('input');i.placeholder='Group name';i.maxLength=40;i.setAttribute('aria-label','Group name');f.appendChild(i);b.appendChild(f);head(b,'Add members');
  const sel=new Set(),ks=Object.keys(USERS);if(!ks.length)b.appendChild(el('p','mu','No other people on BUHAY yet.')).style.padding='10px';
  ks.forEach(k=>{const x=el('button','si');x.appendChild(avEl(USERS[k].uid,USERS[k].n||k));x.appendChild(el('span','',USERS[k].n||k));const ck=el('span','chk');x.appendChild(ck);
    x.onclick=()=>{sel.has(k)?sel.delete(k):sel.add(k);x.classList.toggle('on',sel.has(k));ck.innerHTML=sel.has(k)?IC('tick'):''};b.appendChild(x)});
  const go2=el('button','btn','Create group');go2.style.margin='8px 4px 0';
  go2.onclick=async()=>{const nm=i.value.trim();if(!nm){toast('Give the group a name');return}if(!sel.size){toast('Pick at least one member');return}go2.disabled=true;
    try{const uids=[...sel].map(k=>USERS[k].uid),gid=await FBX.createGroup(RTM.uid,nm,uids),id='g:'+gid;
      CH.push({...mk(id,nm,'group'),rt:1,gid,av:Math.floor(Math.random()*4),memberUids:[RTM.uid,...uids],members:uids.map(u=>uName(u)),adminUids:[RTM.uid],admins:['me'],msgs:[],loaded:0,created:Date.now()});
      closeSheet();openChat(id)}catch(e){go2.disabled=false;fbFail(e)}};b.appendChild(go2)})};
fwdSheet=function(ms){sheet(b=>{head(b,'Forward to');const sel=new Set();
  CH.forEach(c=>{const x=el('button','si');x.appendChild(el('i','a '+A[(c.av||0)%4],c.name[0]));x.appendChild(el('span','',c.name));const k=el('span','chk');x.appendChild(k);x.onclick=()=>{sel.has(c.id)?sel.delete(c.id):sel.add(c.id);x.classList.toggle('on',sel.has(c.id));k.innerHTML=sel.has(c.id)?IC('tick'):''};b.appendChild(x)});
  const go2=el('button','btn','Send');go2.style.margin='8px 4px 0';
  go2.onclick=()=>{if(!sel.size){toast('Choose a chat');return}
    sel.forEach(id=>{const t=CH.find(c=>c.id===id);ms.forEach(m=>{if(t.rt){const ex={fwd:1};if(m.img)ex.img=m.img;const tx=m.t||'📷 Photo';
      (t.type==='group'?FBX.sendGroup(meInfo(),{id:t.gid,members:t.memberUids},tx,ex):FBX.send(meInfo(),t.uid,tx,ex)).catch(()=>toast('Could not forward'))}
      else t.msgs.push({...m,id:uid(),from:'me',ts:Date.now(),st:'delivered',fwd:1,reply:null,rxs:null,star:0,edited:0})})});
    closeSheet();endSel();rcl();save();renderThread(true);toast('Forwarded to '+sel.size+' chat'+(sel.size>1?'s':''))};b.appendChild(go2)})};
attach=function(){sheet(b=>{head(b,'Share');item(b,'image','Photo from gallery',()=>$('#cph').click());item(b,'camera','Camera',()=>$('#cph2').click());item(b,'file','Document',()=>$('#cdoc').click())})};
$('#cdoc').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const c=gc();if(!c||!c.rt){toast('Files can be sent in chats with people');return}
  if(!CL){toast('Sending files needs Cloudinary (see BUHAY-KARNE-KE-STEPS.txt)');return}if(f.size>10*1048576){toast('File is too large (max 10 MB)');return}
  toast('Uploading…');try{const url=await cloudUp(f,'raw');post({kind:'file',fn:f.name,fs:f.size>1048576?(f.size/1048576).toFixed(1)+' MB':Math.max(1,Math.round(f.size/1024))+' KB',url})}catch(x){toast('Upload failed: '+x.message)}};
$('#cms').addEventListener('click',e=>{const fc=e.target.closest('.fc');if(!fc||selMode)return;const bb=fc.closest('.bb'),c=gc(),m=c&&bb&&c.msgs.find(x=>x.id===bb.dataset.id);
  if(m&&m.file&&m.file.url&&/^https:/.test(m.file.url)){if(NAT&&NAT.openUrl)NAT.openUrl(m.file.url);else window.open(m.file.url,'_blank','noopener')}});
async function liveRec(){const c=gc();if(!c||!c.rt){toast('Voice notes can be sent in chats with people');return}
  if(!CL){toast('Voice notes need Cloudinary (see BUHAY-KARNE-KE-STEPS.txt)');return}
  if(!navigator.mediaDevices||!window.MediaRecorder){toast('Voice notes are not supported on this device');return}
  try{const s=await navigator.mediaDevices.getUserMedia({audio:true}),mr=new MediaRecorder(s),ch=[];mr.ondataavailable=e=>ch.push(e.data);
    REC={mr,s,ch,t0:Date.now(),send:false,tm:setInterval(()=>{$('#rtm').textContent=fD((Date.now()-REC.t0)/1000)},250)};
    mr.onstop=async()=>{const r=REC;clearInterval(r.tm);r.s.getTracks().forEach(t=>t.stop());REC=null;$('#rec').hidden=true;$('#cf2').hidden=false;
      if(r.send){const d=Math.max(1,Math.round((Date.now()-r.t0)/1000));toast('Sending voice note…');try{const url=await cloudUp(new Blob(r.ch,{type:r.mr.mimeType||'audio/webm'}),'video');post({kind:'voice',url,d})}catch(x){toast('Could not send: '+x.message)}}};
    mr.start();$('#rtm').textContent='0:00';$('#cf2').hidden=true;$('#rec').hidden=false}catch(x){toast('Microphone permission was denied')}}
$('#cmc').onclick=liveRec;
/* AI Buddy (real, through your own proxy) */
respond=async function(c,trig){if(!c||c.rt||c.type!=='ai'||c.responding)return;c.responding=1;c.typing='AI Buddy';if(CURCH===c.id&&CUR==='chat')renderThread(true);rcl();
  let text;try{const hist=c.msgs.slice(-10).filter(m=>!m.del&&m.kind!=='sys').map(m=>({role:m.from==='me'?'user':'assistant',content:pvt(m)}));
    text=await aiAsk('You are AI Buddy inside BUHAY, a friendly social and creative app. Reply in the user\'s language (Hinglish is fine), warm and under 60 words.',hist,300)}
  catch(e){text=e.message==='noai'?'AI Buddy is not connected yet. The app owner needs to add the aiEndpoint (see BUHAY-KARNE-KE-STEPS.txt).':'Sorry, I could not answer right now. Please try again.'}
  c.typing=null;c.responding=0;c.msgs.push({id:uid(),from:'AI Buddy',t:text,ts:Date.now()});
  if(CURCH===c.id&&CUR==='chat')renderThread(true);else c.unread=(c.unread||0)+1;rcl();save()};

/* ============ voice / video calls (WebRTC, signalling via Firestore) ============ */
const ICE=(CX.iceServers&&CX.iceServers.length)?CX.iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'}];
const CALLX={id:null,pc:null,local:null,side:'',mode:'voice',chat:null,t0:0,tm:null,to:null,un:[],incoming:null,q:[]};
function callUI(name,uid,mode,status,inc){$('#cn2').textContent=name;const a=$('#ca');a.className='a '+A[hue(uid||name)%4];a.style.backgroundImage='';a.textContent=name[0];paintAv(a,uid);$('#cs2').textContent=status;
  $('#call').dataset.mode=mode;$('#cans').hidden=!inc;$('#cmu').style.display=inc?'none':'';$('#cvd').style.display=(mode==='video'&&!inc)?'':'none';$('#csp').style.display='none';$('#lvid').style.display=(mode==='video'&&!inc)?'':'none';$('#cmu').classList.remove('on');$('#cvd').classList.remove('on');$('#call').hidden=false}
function newPC(){const pc=new RTCPeerConnection({iceServers:ICE});CALLX.pc=pc;
  pc.ontrack=ev=>{const rv=$('#rvid');if(rv.srcObject!==ev.streams[0])rv.srcObject=ev.streams[0];rv.play().catch(()=>{})};
  pc.onconnectionstatechange=()=>{const s=pc.connectionState;if(s==='connected')startTimer();else if(s==='failed'){toast('Call connection failed. This network may need a TURN server.');hangup(false)}};return pc}
function startTimer(){if(CALLX.t0)return;CALLX.t0=Date.now();clearTimeout(CALLX.to);CALLX.tm=setInterval(()=>{$('#cs2').textContent=fD((Date.now()-CALLX.t0)/1000)},500);$('#cs2').textContent='0:00'}
const getMedia=mode=>navigator.mediaDevices.getUserMedia({audio:true,video:mode==='video'?{facingMode:'user'}:false});
function cleanupCall(){clearInterval(CALLX.tm);clearTimeout(CALLX.to);CALLX.un.forEach(f=>{try{f()}catch(e){}});if(CALLX.local)CALLX.local.getTracks().forEach(t=>t.stop());if(CALLX.pc){try{CALLX.pc.close()}catch(e){}}
  ['rvid','lvid'].forEach(i=>{const v=$('#'+i);if(v)v.srcObject=null});$('#call').hidden=true;Object.assign(CALLX,{id:null,pc:null,local:null,side:'',t0:0,tm:null,to:null,un:[],incoming:null,q:[],chat:null})}
function hangup(remoteEnded,state){const k={...CALLX};if(!k.id&&!k.pc&&!k.incoming){cleanupCall();return}
  const dur=k.t0?Math.round((Date.now()-k.t0)/1000):0;cleanupCall();
  if(k.id&&!remoteEnded)FBX.callUpdate(k.id,{state:state||(dur?'ended':(k.side==='caller'?'missed':'declined'))}).catch(()=>{});
  if(k.side==='caller'&&k.chat&&!remoteEnded||(k.side==='caller'&&k.chat&&dur))FBX.send(meInfo(),k.chat.uid,(k.mode==='video'?'📹 Video call':'📞 Voice call')+(dur?' · '+fD(dur):' · not answered'),{}).catch(()=>{});
  if(state==='missed')toast('No answer')}
async function liveStartCall(mode){const c=gc();if(!c||c.blk)return;if(!c.rt||c.type==='group'){toast('Calls work in one-to-one chats with people');return}
  if(CALLX.pc||CALLX.incoming){toast('You are already in a call');return}
  if(!navigator.mediaDevices||!window.RTCPeerConnection){toast('Calls are not supported on this device');return}
  CALLX.side='caller';CALLX.mode=mode;CALLX.chat=c;callUI(c.name,c.uid,mode,mode==='video'?'Video calling…':'Calling…',false);
  try{const stream=await getMedia(mode);if(CALLX.side!=='caller'){stream.getTracks().forEach(t=>t.stop());return}CALLX.local=stream;$('#lvid').srcObject=stream;
    const pc=newPC();stream.getTracks().forEach(t=>pc.addTrack(t,stream));
    pc.onicecandidate=ev=>{if(!ev.candidate)return;const j=ev.candidate.toJSON();if(CALLX.id)FBX.addIce(CALLX.id,'caller',j).catch(()=>{});else CALLX.q.push(j)};
    const offer=await pc.createOffer();await pc.setLocalDescription(offer);
    const id=await FBX.callCreate(RTM.uid,c.uid,mode,offer);
    if(CALLX.pc!==pc){FBX.callUpdate(id,{state:'ended'}).catch(()=>{});return}
    CALLX.id=id;CALLX.q.splice(0).forEach(j=>FBX.addIce(id,'caller',j).catch(()=>{}));
    const pend=[],addC=j=>{if(pc.remoteDescription)pc.addIceCandidate(j).catch(()=>{});else pend.push(j)};
    CALLX.un.push(FBX.watchCall(id,async d=>{if(CALLX.pc!==pc)return;if(!d){hangup(true);return}
      if(d.answer&&!pc.remoteDescription){try{await pc.setRemoteDescription(d.answer);pend.splice(0).forEach(addC)}catch(e){}}
      if(d.state==='declined'){toast('Call declined');hangup(true)}else if(d.state==='ended'||d.state==='missed')hangup(true)}),
      FBX.watchIce(id,'callee',addC));
    CALLX.to=setTimeout(()=>{if(!CALLX.t0)hangup(false,'missed')},35000);
  }catch(e){toast(e&&e.name==='NotAllowedError'?'Allow camera / microphone to make calls':'Could not start the call');cleanupCall()}}
startCall=function(m){liveStartCall(m)};endCall=function(){hangup(false)};
function onIncoming(rows){const r=rows.find(x=>Date.now()-(x.at||Date.now())<45000&&!ST.bu.includes(x.from));
  if(!r){if(CALLX.incoming&&!CALLX.pc){CALLX.incoming=null;$('#call').hidden=true}return}
  if(CALLX.pc||CALLX.incoming)return;CALLX.incoming=r;CALLX.side='callee';CALLX.mode=r.mode;
  callUI(uName(r.from),r.from,r.mode,r.mode==='video'?'Incoming video call':'Incoming voice call',true);try{navigator.vibrate&&navigator.vibrate([400,200,400])}catch(e){}}
$('#cans').onclick=async()=>{const r=CALLX.incoming;if(!r)return;CALLX.incoming=null;$('#cans').hidden=true;$('#cmu').style.display='';$('#cs2').textContent='Connecting…';
  try{const stream=await getMedia(r.mode);CALLX.local=stream;$('#lvid').srcObject=stream;const pc=newPC();stream.getTracks().forEach(t=>pc.addTrack(t,stream));CALLX.id=r.id;
    pc.onicecandidate=ev=>{if(ev.candidate)FBX.addIce(r.id,'callee',ev.candidate.toJSON()).catch(()=>{})};
    await pc.setRemoteDescription(r.offer);const ans=await pc.createAnswer();await pc.setLocalDescription(ans);
    await FBX.callUpdate(r.id,{answer:{type:ans.type,sdp:ans.sdp},state:'active'});
    CALLX.un.push(FBX.watchIce(r.id,'caller',j=>pc.addIceCandidate(j).catch(()=>{})),FBX.watchCall(r.id,d=>{if(CALLX.pc!==pc)return;if(!d||d.state==='ended'||d.state==='missed')hangup(true)}));
    $('#cvd').style.display=r.mode==='video'?'':'none';$('#lvid').style.display=r.mode==='video'?'':'none'}
  catch(e){toast(e&&e.name==='NotAllowedError'?'Allow camera / microphone to answer calls':'Could not answer the call');FBX.callUpdate(r.id,{state:'declined'}).catch(()=>{});cleanupCall()}};
$('#cen').onclick=()=>{if(CALLX.incoming&&!CALLX.pc){FBX.callUpdate(CALLX.incoming.id,{state:'declined'}).catch(()=>{});cleanupCall();return}hangup(false)};
$('#cmu').onclick=e=>{const on=e.currentTarget.classList.toggle('on');if(CALLX.local)CALLX.local.getAudioTracks().forEach(t=>t.enabled=!on)};
$('#cvd').onclick=e=>{const on=e.currentTarget.classList.toggle('on');if(CALLX.local)CALLX.local.getVideoTracks().forEach(t=>t.enabled=!on)};

/* ============ AI Studio (image generation) ============ */
let GEN=null;
$$('#modes .chip').forEach((b,i)=>{if(i>0)b.classList.add('soon')});
$('#modes').addEventListener('click',e=>{const b=e.target.closest('.chip');if(b&&b.classList.contains('soon')){e.stopImmediatePropagation();e.preventDefault();toast('Video and avatar generation are not available yet. Image works now.')}},true);
async function genBlob(){const r=await fetch(GEN);if(!r.ok)throw new Error('fetch');return await r.blob()}
function genActions(){let a=$('#genact');if(!a){a=el('div','chips');a.id='genact';a.style.marginTop='12px';$('#enh').after(a);const note=el('small','mu','Images are made by the free pollinations.ai service.');note.id='gennote';note.style.cssText='display:block;margin-top:8px;color:#fff9';a.after(note)}
  a.innerHTML='';[['Save','download',async()=>{try{saveBlob('buhay-ai-'+Date.now()+'.jpg',await genBlob())}catch(e){toast('Could not save the image')}}],
   ['Post','send',async()=>{try{const u=URL.createObjectURL(await genBlob());PIMG=await shrink(u,520);URL.revokeObjectURL(u);$('#cppi').src=PIMG;$('#cpp').hidden=false;go('home')}catch(e){toast('Could not use the image')}}],
   ['Edit','sliders',async()=>{try{openEd(URL.createObjectURL(await genBlob()))}catch(e){toast('Could not open the image')}}]].forEach(([t,i,f])=>{const b=el('button','chip',t);b.onclick=f;a.appendChild(b)})}
$('#gen').onclick=async()=>{const o=$('#out'),v=$('#pi').value.trim();if(!v){o.className='out';o.textContent='Type an idea first';return}
  o.className='out ld';o.style.cssText='';o.textContent='Creating…';$('#enh').textContent='';const g=$('#gen');g.disabled=true;let prompt=v;
  if(CX.aiEndpoint){try{prompt=(await aiAsk('Rewrite the user idea as one vivid, detailed text-to-image prompt, max 40 words. Reply with only the prompt.',[{role:'user',content:v}],120)).trim()||v;$('#enh').textContent='Pro prompt: '+prompt}catch(e){}}
  const url='https://image.pollinations.ai/prompt/'+encodeURIComponent(prompt)+'?width=768&height=768&nologo=true&seed='+Math.floor(Math.random()*1e6),img=new Image();let done=false;
  const fin=ok=>{if(done)return;done=true;g.disabled=false;if(!ok){o.className='out';o.textContent='Could not create the image. Please try again in a moment.'}};
  img.onload=()=>{if(done)return;o.className='out';o.textContent='';o.style.cssText='padding:0;height:auto;aspect-ratio:1/1;overflow:hidden';img.style.cssText='width:100%;height:100%;object-fit:cover';o.appendChild(img);GEN=url;genActions();fin(true)};
  img.onerror=()=>fin(false);img.src=url;setTimeout(()=>fin(false),90000)};
$$('.right .col .im').forEach((d,i)=>{const P=['Castle floating above purple clouds','A fluffy cat in golden light','Sunset over a calm lake'];d.style.cursor='pointer';d.onclick=()=>{$('#pi').value=P[i];go('studio')}});

/* ============ Create tools ============ */
$('#dx').onclick=async()=>{const dc=$('#dc'),R0=dc.getBoundingClientRect(),W=1080,H=Math.round(W*R0.height/R0.width),k=W/R0.width,cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');
  const m=(getComputedStyle(dc).backgroundImage.match(/rgba?\([^)]*\)/g)||['rgb(168,85,247)','rgb(255,255,255)']);const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,m[0]);g.addColorStop(1,m[1]||'#fff');x.fillStyle=g;x.fillRect(0,0,W,H);
  const dt=$('#dt'),lines=dt.innerText.split('\n').map(s=>s.trim()).filter(Boolean),dr=dt.getBoundingClientRect();x.fillStyle='#3a1aa0';x.textAlign='center';x.textBaseline='middle';
  const fs=Math.min(110,(dr.height*k)/Math.max(1,lines.length)*.8);x.font='italic 800 '+fs+'px Georgia,serif';const cy=(dr.top-R0.top+dr.height/2)*k;lines.forEach((l,i)=>x.fillText(l,W/2,cy+(i-(lines.length-1)/2)*fs*1.15,W*.9));
  $$('.el',dc).forEach(e=>{const r=e.getBoundingClientRect(),cx=(r.left-R0.left+r.width/2)*k,cyy=(r.top-R0.top+r.height/2)*k;
    if(e.classList.contains('sh')){x.fillStyle='rgba(255,255,255,.88)';const w=r.width*k,h=r.height*k;x.beginPath();x.roundRect?x.roundRect(cx-w/2,cyy-h/2,w,h,w*.2):x.rect(cx-w/2,cyy-h/2,w,h);x.fill()}
    else{x.fillStyle='#fde047';x.font='700 '+(r.height*k*.9)+'px sans-serif';x.fillText(e.textContent||'★',cx,cyy)}});
  const blob=await new Promise(r=>cv.toBlob(r,'image/png'));if(blob)saveBlob('buhay-design.png',blob);else toast('Could not export the design')};
const TPL=[['Good<br>Vibes','linear-gradient(135deg,#ec4899,#ffffff)'],['Dream<br>Big','linear-gradient(135deg,#6366f1,#ffffff)'],['Golden<br>Hour','linear-gradient(135deg,#f59e0b,#ffffff)'],['Stay<br>Wild','linear-gradient(135deg,#10b981,#ffffff)']];
function tplSheet(){sheet(b=>{head(b,'Templates');TPL.forEach(t=>item(b,'grid',t[0].replace('<br>',' '),()=>{go('design');$('#dc').style.background=t[1];$('#dt').innerHTML=t[0]}))})}
function audioSheet(){sheet(b=>{head(b,'Voice recorder');const st=el('p','mu','Tap record to start.');st.style.padding='8px 10px';b.appendChild(st);let mr=null,ch=[],stream=null,blob=null,t0=0,tm=null;
  const rec=el('button','btn','● Record');rec.style.margin='4px';b.appendChild(rec);const box=el('div');box.style.padding='6px 4px';b.appendChild(box);
  rec.onclick=async()=>{if(mr&&mr.state==='recording'){mr.stop();return}
    if(!navigator.mediaDevices||!window.MediaRecorder){toast('Recording is not supported on this device');return}
    try{stream=await navigator.mediaDevices.getUserMedia({audio:true});ch=[];mr=new MediaRecorder(stream);mr.ondataavailable=e=>ch.push(e.data);t0=Date.now();box.innerHTML='';
      mr.onstop=()=>{clearInterval(tm);stream.getTracks().forEach(t=>t.stop());blob=new Blob(ch,{type:mr.mimeType||'audio/webm'});rec.textContent='● Record again';st.textContent='Recorded '+fD((Date.now()-t0)/1000);
        const au=document.createElement('audio');au.controls=true;au.src=URL.createObjectURL(blob);au.style.cssText='width:100%;margin-bottom:8px';box.appendChild(au);
        const sv=el('button','btn ghost','Save to phone');sv.onclick=()=>saveBlob('buhay-voice-'+Date.now()+'.'+((blob.type.includes('ogg'))?'ogg':'webm'),blob);box.appendChild(sv)};
      mr.start();rec.textContent='■ Stop';tm=setInterval(()=>{st.textContent='Recording… '+fD((Date.now()-t0)/1000)},300)}catch(e){toast('Microphone permission was denied')}}})}
$$('#create .tool').forEach(b=>{const t=b.textContent;if(/Template/.test(t))b.onclick=tplSheet;else if(/Audio/.test(t))b.onclick=audioSheet});
{const q=$$('#create .card')[1];if(q){const bs=$$('.tool',q);const f=[()=>{go('photo');$('#ptabs [data-p=txt]').click()},()=>go('design'),()=>{go('photo');$('#ptabs [data-p=fil]').click()}];
  bs.forEach((b,i)=>{if(i<3)b.onclick=f[i]===undefined?null:(i===1?()=>{go('design');setTimeout(()=>$('#aK').click(),50)}:f[i]);else b.remove()})}}
$('#pe-gal').lastChild.textContent=' Save to phone';
$('#pe-gal').onclick=async()=>{if(!need())return;const c=rend(2048),blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.92));saveBlob('buhay-photo-'+Date.now()+'.jpg',blob)};
$('#pe-av').onclick=()=>{if(!need())return;const c=rend(1024),s=Math.min(c.width,c.height),o=document.createElement('canvas');o.width=o.height=320;o.getContext('2d').drawImage(c,(c.width-s)/2,(c.height-s)/2,s,s,0,0,320,320);MD.avatar=o.toDataURL('image/jpeg',.82);renderProfile();rst();liveSaveMedia();toast('Profile photo updated')};
$('#camuse').onclick=()=>sheet(b=>{head(b,'Use photo');
  item(b,'send','Post to feed',async()=>{PIMG=await shrink(CAMIMG,520);$('#cppi').src=PIMG;$('#cpp').hidden=false;go('home');setTimeout(()=>$('#ci').focus(),200)});
  item(b,'spark','Add to your story',async()=>{addSlide({src:await shrink(CAMIMG,720)});go('home')});
  item(b,'sliders','Edit in Photo Editor',()=>openEd(CAMIMG));
  item(b,'download','Save to phone',async()=>{const bl=await (await fetch(CAMIMG)).blob();saveBlob('buhay-photo-'+Date.now()+'.jpg',bl)})});

/* ---------- Video editor (real: trim, speed, filter, text, sticker, export to WebM) ---------- */
const VE={url:'',dur:0,s:0,e:0,rate:1,fi:0,ad:0,mute:false,txt:'',stk:'',rec:false,blob:null};
const VF=['none','saturate(1.7)','grayscale(1)','sepia(.8)','hue-rotate(70deg)','contrast(1.3) brightness(1.1)'],VA=[1,.8,1.3],VR=[.5,1,1.5,2];
const vid=()=>$('#evid'),vfilter=()=>(VF[VE.fi]==='none'?'':VF[VE.fi]+' ')+'brightness('+VA[VE.ad]+')';
function veUI(){const v=vid();v.style.filter=vfilter();v.muted=VE.mute;$('#sl2').textContent=VE.rate+'x';$('#veov').textContent='';
  if(VE.txt){const t=el('div','vet',VE.txt);$('#veov').appendChild(t)}if(VE.stk){const t=el('div','ves',VE.stk);$('#veov').appendChild(t)}
  $('#vet').textContent=VE.dur?fD(VE.s)+' – '+fD(VE.e)+' ('+fD(Math.max(0,(VE.e-VE.s)/VE.rate))+' long)':''}
function veBuild(){if(vid())return;const pv=$('#pv'),v=document.createElement('video');v.id='evid';v.playsInline=true;v.style.cssText='width:100%;height:100%;object-fit:contain;display:none;border-radius:inherit';pv.appendChild(v);
  const ov=el('div','veov');ov.id='veov';pv.appendChild(ov);const hint=el('div','vehint','Tap “Media” to choose a video');hint.id='vehint';pv.appendChild(hint);
  const tp=el('div','vetrim');tp.hidden=true;tp.id='vetrimp';tp.innerHTML='<label>Start<input type="range" id="vs" min="0" max="1000" value="0"></label><label>End<input type="range" id="ve" min="0" max="1000" value="1000"></label><small id="vet" class="mu"></small>';$('#ph').before(tp);
  const inp=document.createElement('input');inp.type='file';inp.accept='video/*';inp.hidden=true;inp.id='vefile';document.body.appendChild(inp);
  inp.onchange=()=>{const f=inp.files[0];inp.value='';if(!f)return;if(VE.url)URL.revokeObjectURL(VE.url);VE.url=URL.createObjectURL(f);v.src=VE.url;v.style.display='block';$('#vehint').style.display='none';pv.style.backgroundImage='none';pv.style.background='#000'};
  v.onloadedmetadata=()=>{VE.dur=v.duration||0;VE.s=0;VE.e=VE.dur;$('#vs').value=0;$('#ve').value=1000;$$('#trk .cl').forEach((c,i)=>c.style.display=i?'none':'');veUI()};
  v.ontimeupdate=()=>{if(VE.rec)return;if(v.currentTime>=VE.e){v.pause();v.currentTime=VE.s;pl=0;$('#play use').setAttribute('href','#i-play')}const span=Math.max(.1,VE.e-VE.s);$('#ph').value=Math.max(0,Math.min(100,(v.currentTime-VE.s)/span*100))};
  $('#vs').oninput=e=>{VE.s=Math.min(e.target.value/1000*VE.dur,VE.e-.3);v.currentTime=VE.s;veUI()};$('#ve').oninput=e=>{VE.e=Math.max(e.target.value/1000*VE.dur,VE.s+.3);veUI()};
  $('#ph').oninput=e=>{if(VE.dur)v.currentTime=VE.s+e.target.value/100*(VE.e-VE.s)};
  const rail=$$('#editor .rail button');
  rail[0].onclick=()=>inp.click();
  rail[1].onclick=()=>{VE.mute=!VE.mute;veUI();toast(VE.mute?'Original sound off':'Original sound on')};
  rail[2].onclick=()=>sheet(b=>{head(b,'Add text');const f=el('label','fld2'),i=el('input');i.placeholder='Type text…';i.maxLength=40;i.value=VE.txt;i.setAttribute('aria-label','Text');f.appendChild(i);b.appendChild(f);const g=el('button','btn','Done');g.style.margin='8px 4px 0';g.onclick=()=>{VE.txt=i.value.trim();closeSheet();veUI()};b.appendChild(g)});
  rail[3].onclick=()=>sheet(b=>{head(b,'Add sticker');const g=el('div','eg');['','😍','🔥','✨','🎉','😎','❤️','🥳','🌈'].forEach(s=>{const x=el('button','',s||'None');x.type='button';x.onclick=()=>{VE.stk=s;closeSheet();veUI()};g.appendChild(x)});b.appendChild(g)});
  rail[4].onclick=()=>$('#fi').click();
  $('#fi').onclick=()=>{VE.fi=(VE.fi+1)%VF.length;veUI();toast('Filter '+(VE.fi||'off'))};
  $('#ad').onclick=()=>{VE.ad=(VE.ad+1)%VA.length;veUI();toast('Brightness '+['normal','softer','brighter'][VE.ad])};
  $('#spd').onclick=()=>{VE.rate=VR[(VR.indexOf(VE.rate)+1)%VR.length];v.playbackRate=VE.rate;veUI()};
  $('#sp').style.display='none';$('#tr').onclick=()=>{if(!VE.url){toast('Choose a video first');return}tp.hidden=!tp.hidden};
  $('#play').onclick=()=>{if(!VE.url){toast('Choose a video first');return}if(v.paused){if(v.currentTime<VE.s||v.currentTime>=VE.e-.05)v.currentTime=VE.s;v.playbackRate=VE.rate;v.play().catch(()=>{});pl=1}else{v.pause();pl=0}$('#play use').setAttribute('href',v.paused?'#i-play':'#i-pause')};
  v.onpause=()=>$('#play use').setAttribute('href','#i-play');
  $('#ex').onclick=veExport;
  veUI()}
async function veExport(){const v=vid();if(!VE.url){toast('Choose a video first');return}if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream){toast('Video export is not supported on this device');return}
  if(VE.rec)return;const w=Math.min(v.videoWidth||640,1280),h=Math.round(w*((v.videoHeight||360)/(v.videoWidth||640))),cv=document.createElement('canvas');cv.width=w;cv.height=h;const x=cv.getContext('2d'),cs=cv.captureStream(30);
  try{const vs=v.captureStream&&v.captureStream();if(vs&&!VE.mute)vs.getAudioTracks().forEach(t=>cs.addTrack(t))}catch(e){}
  const mt=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t))||'',ch=[],mr=new MediaRecorder(cs,mt?{mimeType:mt}:undefined);
  mr.ondataavailable=e=>{if(e.data&&e.data.size)ch.push(e.data)};
  const bf=(VF[VE.fi]==='none'?'':VF[VE.fi]+' ')+'brightness('+VA[VE.ad]+')';
  const draw=()=>{if(!VE.rec)return;x.filter=bf;x.drawImage(v,0,0,w,h);x.filter='none';
    if(VE.txt){x.font='700 '+Math.round(h*.08)+'px sans-serif';x.textAlign='center';x.fillStyle='#fff';x.shadowColor='rgba(0,0,0,.6)';x.shadowBlur=8;x.fillText(VE.txt,w/2,h*.88,w*.9);x.shadowBlur=0}
    if(VE.stk){x.font=Math.round(h*.16)+'px sans-serif';x.textAlign='center';x.fillText(VE.stk,w*.85,h*.18)}requestAnimationFrame(draw)};
  const finish=()=>{if(!VE.rec)return;VE.rec=false;v.pause();v.removeEventListener('timeupdate',chk);mr.stop()};
  const chk=()=>{if(v.currentTime>=VE.e-.05||v.ended)finish()};
  mr.onstop=()=>{const blob=new Blob(ch,{type:mt||'video/webm'});v.currentTime=VE.s;toast('Video ready');
    sheet(b=>{head(b,'Your video is ready');item(b,'download','Save to phone',()=>saveBlob('buhay-video-'+Date.now()+'.webm',blob));
      if(CL)item(b,'reels','Share as reel',async()=>{try{toast('Uploading…');const url=await cloudUp(blob,'video');await FBX.addPost('reels',L.uid,PF.name,{text:VE.txt||'',mk:'video',url});toast('Reel shared')}catch(e){toast('Upload failed: '+e.message)}})})};
  v.pause();v.currentTime=VE.s;await new Promise(r=>{const f=()=>{v.removeEventListener('seeked',f);r()};v.addEventListener('seeked',f);setTimeout(r,1500)});
  VE.rec=true;toast('Exporting… keep this screen open');v.playbackRate=VE.rate;v.addEventListener('timeupdate',chk);v.addEventListener('ended',chk);mr.start(500);try{await v.play()}catch(e){VE.rec=false;toast('Could not play the video');return}draw()}
const _go2=go;go=function(n){_go2(n);if(n==='editor')veBuild()};
if(CUR==='editor')veBuild();

/* ---------- start ---------- */
rfeed();rrLive();mas('all','');rst();renderProfile();nl();
})();
