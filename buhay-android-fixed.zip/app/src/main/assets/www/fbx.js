// BUHAY Firebase layer (ES module). Exposes window.FBX for the app.
// Moved out of index.html so it can be edited easily.
const cfg = window.BUHAY_FIREBASE;
if (cfg && cfg.apiKey && !/^PASTE/.test(cfg.apiKey)) {
  try {
    const V = 'https://www.gstatic.com/firebasejs/10.12.2/';
    const [{ initializeApp }, A, F, D] = await Promise.all([
      import(V + 'firebase-app.js'),
      import(V + 'firebase-auth.js'),
      import(V + 'firebase-firestore.js'),
      import(V + 'firebase-database.js')
    ]);
    const app = initializeApp(cfg), auth = A.getAuth(app), db = F.getFirestore(app), rtdb = D.getDatabase(app);
    let signing = false, presUn = null;
    const ms = t => t && t.toMillis ? t.toMillis() : 0;
    const cid = (a, b) => [a, b].sort().join('_');
    const col = (...p) => F.collection(db, ...p);
    const dref = (...p) => F.doc(db, ...p);
    const T = () => F.serverTimestamp();
    const udoc = uid => dref('users', uid), cdoc = id => dref('chats', id), mdoc = (c, m) => dref('chats', c, 'messages', m);
    const snapRows = q => q.docs.map(d => {
      const x = d.data({ serverTimestamps: 'estimate' });
      return { id: d.id, ...x, ts: ms(x.ts) || Date.now() };
    });

    window.FBX = {
      /* ---------- auth ---------- */
      onAuth: cb => A.onAuthStateChanged(auth, u => { if (signing) return; cb(u); }),
      async signIn(e, p, rem) {
        try { await A.setPersistence(auth, rem ? A.browserLocalPersistence : A.browserSessionPersistence); } catch (x) {}
        return (await A.signInWithEmailAndPassword(auth, e, p)).user;
      },
      async signUp(x) {
        signing = true;
        try {
          if ((await F.getDoc(dref('usernames', x.un))).exists()) { const er = new Error('taken'); er.code = 'app/username-taken'; throw er; }
          const cr = await A.createUserWithEmailAndPassword(auth, x.em, x.pw);
          await A.updateProfile(cr.user, { displayName: x.fn });
          const b = F.writeBatch(db);
          b.set(udoc(cr.user.uid), { name: x.fn, username: x.un, email: x.em, bio: 'Simple. Fast. Private.', createdAt: T(), privacy: { read: 1, online: 1 } });
          b.set(dref('usernames', x.un), { uid: cr.user.uid });
          await b.commit();
          try { await A.sendEmailVerification(cr.user); } catch (e) {}
          return cr.user;
        } finally { signing = false; }
      },
      async google() {
        const cid0 = (cfg.googleWebClientId || '');
        if (window.AndroidGoogleAuth && typeof window.AndroidGoogleAuth.signIn === 'function') {
          return await new Promise((resolve, reject) => {
            let settled = false;
            const to = setTimeout(() => {
              if (settled) return; settled = true; delete window.__buhayGoogleResult;
              const e = new Error('timeout'); e.code = 'auth/webview-google-signin-failed'; reject(e);
            }, 120000);
            window.__buhayGoogleResult = (idToken, error) => {
              if (settled) return; settled = true; clearTimeout(to); delete window.__buhayGoogleResult;
              if (error) { const e = new Error(error); e.code = 'auth/webview-google-signin-failed'; e.nativeMessage = error; reject(e); return; }
              A.signInWithCredential(auth, A.GoogleAuthProvider.credential(idToken)).then(x => resolve(x.user)).catch(reject);
            };
            try { window.AndroidGoogleAuth.signIn(cid0); }
            catch (e) { settled = true; clearTimeout(to); delete window.__buhayGoogleResult; reject(e); }
          });
        }
        return (await A.signInWithPopup(auth, new A.GoogleAuthProvider())).user;
      },
      reset: e => A.sendPasswordResetEmail(auth, e),
      idToken: async () => auth.currentUser ? await auth.currentUser.getIdToken() : '',
      async signOut(uid) {
        try { if (uid) await D.set(D.ref(rtdb, 'status/' + uid), { state: 'offline', last: D.serverTimestamp() }); } catch (e) {}
        await A.signOut(auth);
      },
      providerId: () => (auth.currentUser && auth.currentUser.providerData[0] && auth.currentUser.providerData[0].providerId) || '',
      async deleteAccount(uid, un, pw) {
        const u = auth.currentUser;
        if (!u) throw new Error('Not signed in');
        const pid = FBX.providerId();
        if (pid === 'password') {
          if (!pw) { const e = new Error('pw'); e.code = 'app/need-password'; throw e; }
          await A.reauthenticateWithCredential(u, A.EmailAuthProvider.credential(u.email, pw));
        } else {
          const last = Date.parse(u.metadata.lastSignInTime || '') || 0;
          if (Date.now() - last > 5 * 60 * 1000) { const e = new Error('recent'); e.code = 'auth/requires-recent-login'; throw e; }
        }
        const wipe = async (qq) => { const s = await F.getDocs(qq); for (const d of s.docs) { try { await F.deleteDoc(d.ref); } catch (e) {} } };
        for (const k of ['posts', 'reels', 'stories']) await wipe(F.query(col(k), F.where('by', '==', uid)));
        await wipe(F.query(col('follows'), F.where('from', '==', uid)));
        await wipe(F.query(col('follows'), F.where('to', '==', uid)));
        try { await F.deleteDoc(dref('users', uid, 'media', 'cover')); } catch (e) {}
        try { await F.deleteDoc(dref('userdata', uid)); } catch (e) {}
        try { await F.deleteDoc(dref('usernames', un)); } catch (e) {}
        try { await F.deleteDoc(udoc(uid)); } catch (e) {}
        try { await D.remove(D.ref(rtdb, 'status/' + uid)); } catch (e) {}
        await A.deleteUser(u);
      },

      /* ---------- users / profile ---------- */
      async ensureUser(u) {
        let s = await F.getDoc(udoc(u.uid));
        if (!s.exists()) {
          const un = ((u.email || 'user').split('@')[0].toLowerCase().replace(/[^a-z0-9_.]/g, '') || 'user').slice(0, 14) + Math.floor(Math.random() * 900 + 100);
          const b = F.writeBatch(db);
          b.set(udoc(u.uid), { name: u.displayName || un, username: un, email: u.email || '', bio: 'Simple. Fast. Private.', createdAt: T(), privacy: { read: 1, online: 1 } });
          b.set(dref('usernames', un), { uid: u.uid });
          await b.commit();
          s = await F.getDoc(udoc(u.uid));
        }
        const d = s.data();
        d.createdMs = ms(d.createdAt);
        return d;
      },
      watchUsers: (uid, cb) => F.onSnapshot(col('users'), q => cb(q.docs.filter(x => x.id !== uid).map(x => {
        const d = x.data();
        return { uid: x.id, name: d.name, username: d.username, bio: d.bio, site: d.site || '', loc: d.loc || '', av: d.av || '', priv: !!(d.privacy && d.privacy.priv), createdMs: ms(d.createdAt) };
      })), () => { }),
      profile: (uid, p) => F.updateDoc(udoc(uid), p),
      async privacy(uid, p) { await F.updateDoc(udoc(uid), { privacy: p }); },
      async getCover(uid) { try { const s = await F.getDoc(dref('users', uid, 'media', 'cover')); return s.exists() ? (s.data().src || '') : ''; } catch (e) { return ''; } },
      setCover: (uid, src) => F.setDoc(dref('users', uid, 'media', 'cover'), { src }),
      async getState(uid) { try { const s = await F.getDoc(dref('userdata', uid)); return s.exists() ? s.data() : {}; } catch (e) { return {}; } },
      setState: (uid, o) => F.setDoc(dref('userdata', uid), o, { merge: true }),
      report: (uid, target, reason) => F.addDoc(col('reports'), { by: uid, target, reason, ts: T() }),

      /* ---------- presence / typing ---------- */
      watchPresence: cb => D.onValue(D.ref(rtdb, 'status'), sn => cb(sn.val() || {})),
      presence(uid, online) {
        if (presUn) presUn();
        presUn = D.onValue(D.ref(rtdb, '.info/connected'), sn => {
          if (sn.val() !== true) return;
          const r = D.ref(rtdb, 'status/' + uid);
          D.onDisconnect(r).set({ state: 'offline', last: D.serverTimestamp() }).then(() => D.set(r, { state: online ? 'online' : 'offline', last: D.serverTimestamp() }));
        });
      },
      watchTyping: (chatId, peer, cb) => D.onValue(D.ref(rtdb, `typing/${chatId}/${peer}`), sn => cb(!!sn.val())),
      async typing(chatId, uid, on) { try { await D.set(D.ref(rtdb, `typing/${chatId}/${uid}`), on ? true : null); } catch (e) {} },

      /* ---------- chats (1:1 and groups) ---------- */
      watchChats: (uid, cb) => F.onSnapshot(F.query(col('chats'), F.where('members', 'array-contains', uid)), q => cb(q.docs.map(x => {
        const d = x.data(), seen = {};
        Object.entries(d.seen || {}).forEach(([k, v]) => seen[k] = ms(v));
        return { id: x.id, members: d.members, last: d.last, unread: d.unread || {}, seen, updatedAt: ms(d.updatedAt), type: d.type || 'dm', name: d.name || '', admins: d.admins || [], dis: d.dis || 0 };
      })), () => { }),
      watchMsgs: (chatId, cb) => F.onSnapshot(F.query(col('chats', chatId, 'messages'), F.orderBy('at')), q => cb(q.docs), () => cb([])),
      async send(me, to, text, extra) {
        const chatId = cid(me.uid, to), mem = [me.uid, to].sort();
        await F.setDoc(cdoc(chatId), { members: mem, last: { text: text.slice(0, 120), from: me.uid }, updatedAt: T(), unread: { [to]: F.increment(1) } }, { merge: true });
        await F.addDoc(col('chats', chatId, 'messages'), { from: me.uid, text, at: T(), ...extra });
        await F.setDoc(dref('notifications', chatId + '_' + me.uid), { to, from: me.uid, fromName: me.name, type: 'message', text: text.slice(0, 120), at: T(), read: false });
      },
      async sendGroup(me, chat, text, extra) {
        const un = {};
        chat.members.filter(x => x !== me.uid).forEach(u => { un['unread.' + u] = F.increment(1); });
        await F.updateDoc(cdoc(chat.id), { last: { text: text.slice(0, 120), from: me.uid }, updatedAt: T(), ...un });
        await F.addDoc(col('chats', chat.id, 'messages'), { from: me.uid, text, at: T(), ...extra });
      },
      async createGroup(me, name, uids) {
        const ref = F.doc(col('chats'));
        await F.setDoc(ref, { type: 'group', name, members: [me, ...uids], admins: [me], createdBy: me, last: { text: 'Group created', from: me }, updatedAt: T(), unread: {} });
        return ref.id;
      },
      groupUpdate: (id, o) => F.updateDoc(cdoc(id), o),
      chatSetting: (id, o) => F.updateDoc(cdoc(id), o),
      seen(chatId, uid, rr) { const u = {}; u['unread.' + uid] = 0; if (rr) u['seen.' + uid] = T(); return F.updateDoc(cdoc(chatId), u); },
      edit: (c, m, text) => F.updateDoc(mdoc(c, m), { text, edited: true }),
      delAll: (c, m) => F.updateDoc(mdoc(c, m), { del: true, text: 'This message was deleted' }),
      react: (c, m, uid, e) => F.updateDoc(mdoc(c, m), { ['rxs.' + uid]: e === null ? F.deleteField() : e }),

      /* ---------- notifications ---------- */
      watchNotifs: (uid, cb) => F.onSnapshot(F.query(col('notifications'), F.where('to', '==', uid)), q => cb(q.docs.map(x => ({ id: x.id, ...x.data(), ts: ms(x.data().at) }))), () => { }),
      markNotif: id => F.updateDoc(dref('notifications', id), { read: true }),
      notify: (id, o) => F.setDoc(dref('notifications', id), { ...o, at: T(), read: false }),
      unnotify: id => F.deleteDoc(dref('notifications', id)),

      /* ---------- posts & reels  (kind = 'posts' | 'reels') ---------- */
      watchPosts: (kind, cb) => F.onSnapshot(F.query(col(kind), F.orderBy('ts', 'desc'), F.limit(80)), q => cb(snapRows(q)), () => cb([])),
      async addPost(kind, uid, name, o) {
        const ref = F.doc(col(kind));
        await F.setDoc(ref, { by: uid, name, text: o.text || '', img: o.img || '', url: o.url || '', mk: o.mk || '', ts: T(), lk: 0, cc: 0 });
        return ref.id;
      },
      delPost: (kind, id) => F.deleteDoc(dref(kind, id)),
      async like(kind, id, uid, on) {
        const b = F.writeBatch(db);
        if (on) { b.set(dref(kind, id, 'likes', uid), { ts: T() }); b.update(dref(kind, id), { lk: F.increment(1) }); }
        else { b.delete(dref(kind, id, 'likes', uid)); b.update(dref(kind, id), { lk: F.increment(-1) }); }
        await b.commit();
      },
      watchComments: (kind, id, cb) => F.onSnapshot(F.query(col(kind, id, 'comments'), F.orderBy('ts')), q => cb(snapRows(q)), () => cb([])),
      async addComment(kind, id, uid, name, text) {
        const b = F.writeBatch(db), r = F.doc(col(kind, id, 'comments'));
        b.set(r, { by: uid, name, text, ts: T() });
        b.update(dref(kind, id), { cc: F.increment(1) });
        await b.commit();
        return r.id;
      },
      async delComment(kind, id, cidd) {
        const b = F.writeBatch(db);
        b.delete(dref(kind, id, 'comments', cidd));
        b.update(dref(kind, id), { cc: F.increment(-1) });
        await b.commit();
      },

      /* ---------- follows ---------- */
      follow: (me, to, priv) => F.setDoc(dref('follows', me + '_' + to), { from: me, to, ts: T(), st: priv ? 'req' : 'ok' }),
      approve: (me, from) => F.updateDoc(dref('follows', from + '_' + me), { st: 'ok' }),
      declineReq: (me, from) => F.deleteDoc(dref('follows', from + '_' + me)),
      unfollow: (me, to) => F.deleteDoc(dref('follows', me + '_' + to)),
      watchFollows: (uid, cb) => {
        let a = [], b = [];
        const emit = () => cb(a.filter(x => x.st !== 'req').map(x => x.to), b.filter(x => x.st !== 'req').map(x => x.from), a.filter(x => x.st === 'req').map(x => x.to), b.filter(x => x.st === 'req').map(x => x.from));
        const u1 = F.onSnapshot(F.query(col('follows'), F.where('from', '==', uid)), q => { a = q.docs.map(d => d.data()); emit(); }, () => { });
        const u2 = F.onSnapshot(F.query(col('follows'), F.where('to', '==', uid)), q => { b = q.docs.map(d => d.data()); emit(); }, () => { });
        return () => { u1(); u2(); };
      },
      async followCounts(uid) {
        try {
          const a = await F.getCountFromServer(F.query(col('follows'), F.where('to', '==', uid), F.where('st', '==', 'ok')));
          const b = await F.getCountFromServer(F.query(col('follows'), F.where('from', '==', uid), F.where('st', '==', 'ok')));
          return { followers: a.data().count, following: b.data().count };
        } catch (e) { return { followers: 0, following: 0 }; }
      },

      /* ---------- stories ---------- */
      watchStories: cb => F.onSnapshot(F.query(col('stories'), F.where('ts', '>', F.Timestamp.fromMillis(Date.now() - 864e5)), F.orderBy('ts')), q => cb(snapRows(q)), () => cb([])),
      addStory: (uid, name, o) => F.addDoc(col('stories'), { by: uid, name, ts: T(), ...o }),
      delStory: id => F.deleteDoc(dref('stories', id)),
      viewStory: (id, uid) => F.setDoc(dref('stories', id, 'views', uid), { ts: T() }),
      async storyViews(id) { try { return (await F.getCountFromServer(col('stories', id, 'views'))).data().count; } catch (e) { return 0; } },

      /* ---------- voice / video calls (WebRTC signalling through Firestore) ---------- */
      async callCreate(from, to, mode, offer) {
        const ref = F.doc(col('calls'));
        await F.setDoc(ref, { from, to, mode, offer: { type: offer.type, sdp: offer.sdp }, state: 'ringing', at: T() });
        return ref.id;
      },
      watchIncoming: (uid, cb) => F.onSnapshot(F.query(col('calls'), F.where('to', '==', uid), F.where('state', '==', 'ringing')), q => cb(q.docs.map(d => ({ id: d.id, ...d.data(), at: ms(d.data().at) }))), () => { }),
      watchCall: (id, cb) => F.onSnapshot(dref('calls', id), s => cb(s.exists() ? { id: s.id, ...s.data() } : null), () => { }),
      callUpdate: (id, o) => F.updateDoc(dref('calls', id), o),
      addIce: (id, side, c) => F.addDoc(col('calls', id, side + 'Ice'), c),
      watchIce: (id, side, cb) => F.onSnapshot(col('calls', id, side + 'Ice'), q => q.docChanges().forEach(ch => { if (ch.type === 'added') cb(ch.doc.data()); }), () => { })
    };
    window.dispatchEvent(new Event('fbx-ready'));
  } catch (e) {
    console.error(e);
    window.dispatchEvent(new Event('fbx-error'));
  }
}
