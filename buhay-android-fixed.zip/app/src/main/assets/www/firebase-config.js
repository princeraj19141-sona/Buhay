// BUHAY configuration. Firebase web config is already filled in for project buhay-477bf.
// The OPTIONAL values below switch on extra features. Leave a value empty ("") to keep that feature off.
window.BUHAY_FIREBASE={
  apiKey:"AIzaSyBDQpa5tkdwftx8BNDKmqrsfW3Q9Bc8a9I",
  authDomain:"buhay-477bf.firebaseapp.com",
  databaseURL:"https://buhay-477bf-default-rtdb.firebaseio.com",
  projectId:"buhay-477bf",
  storageBucket:"buhay-477bf.firebasestorage.app",
  messagingSenderId:"329786140274",
  appId:"1:329786140274:web:6c01d5c7fac02da266c4eb",

  // ---- OPTIONAL: fill these in (see BUHAY-KARNE-KE-STEPS.txt) ----
  // Google sign-in: the "Web client ID" from Firebase > Authentication > Google > Web SDK configuration
  googleWebClientId:"",
  // Video upload, voice notes, file sharing and fast image hosting (free account at cloudinary.com)
  cloudinary:{cloud:"",preset:""},
  // AI Buddy chat (your own Cloudflare Worker, code is in the ai-proxy folder)
  aiEndpoint:"",
  // Calls on strict mobile networks: add a TURN server, e.g. [{urls:"turn:...",username:"...",credential:"..."}]
  iceServers:[],
  // Link people get when they use Share (your website / Play Store link). Optional.
  shareUrl:""
};
