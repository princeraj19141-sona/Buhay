BUHAY Android app (WebView wrapper + web app in app/src/main/assets/www).
Pehle BUHAY-KARNE-KE-STEPS.txt padho.
 - app/src/main/assets/www/index.html : poora app UI
 - app/src/main/assets/www/live.js    : real (non-demo) features
 - app/src/main/assets/www/fbx.js     : Firebase layer
 - firebase/                          : Firestore + Realtime Database rules
 - ai-proxy/worker.js                 : optional AI Buddy proxy
 - .github/workflows/build-apk.yml    : APK builder
