BUHAY Android wrapper + automatic APK build

WHAT THIS IS
- This package wraps the supplied BUHAY PWA files in a lightweight Android WebView app.
- GitHub Actions builds a debug APK automatically on push to main, or manually using Run workflow.
- The APK is not signed for Play Store release. It is a test/install APK.

IMPORTANT FIREBASE SETUP
1. The supplied firebase-config.js contains PASTE placeholders.
2. Configure Firebase using the original README.txt instructions.
3. Add appassets.androidplatform.net to Firebase Authentication > Settings > Authorized domains.
4. Email/password authentication should be tested after Firebase setup.
5. Google sign-in uses signInWithPopup in the supplied web app. Google OAuth commonly blocks embedded WebViews; Google sign-in is NOT guaranteed in this wrapper and needs native OAuth integration or a hosted PWA/TWA approach.

BUILD ON GITHUB FROM AN ANDROID PHONE
1. Create a new GitHub repository named buhay-android (Private is fine).
2. Upload/extract ALL files and folders from this ZIP into the repository root. Keep the .github/workflows/build-apk.yml path.
3. Commit to the main branch.
4. Open repository > Actions > Build BUHAY APK > latest successful run.
5. Open Artifacts > BUHAY-debug-APK and download the ZIP. Extract app-debug.apk and install it.
6. If Android asks, allow installing unknown apps for the browser/file manager you used.

BUILD DETAILS
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- compileSdk 35
- minSdk 23
- Application ID: com.buhay.app

LIMITATIONS / REVIEW NOTES
- This environment cannot run the Android SDK build, so the APK must be built by GitHub Actions.
- The original app's Firestore and Realtime Database rules are retained unchanged. Review them before using real users/data.
- The original Firestore rules allow all authenticated users to read all user profile documents.
- Google sign-in popup behavior in embedded Android WebView is not verified and may fail.
- This is a wrapper of the existing web app, not a rewrite into native Kotlin screens.
