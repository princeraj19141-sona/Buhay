BUHAY Android wrapper + automatic APK build

WHAT THIS IS
- This package wraps the supplied BUHAY PWA files in a lightweight Android WebView app.
- GitHub Actions builds a debug APK automatically on push to main, or manually using Run workflow.
- The APK is not signed for Play Store release. It is a test/install APK.

IMPORTANT FIREBASE SETUP
1. The supplied firebase-config.js contains PASTE placeholders.
2. Configure Firebase using the original README.txt instructions.
3. Add appassets.androidplatform.net to Firebase Authentication > Settings > Authorized domains.
4. Email/password authentication should be tested after Firebase setup.
5. Google sign-in uses signInWithPopup in the supplied web app. Google OAuth commonly blocks embedded WebViews; Google sign-in is NOT guaranteed in this wrapper and needs native OAuth integration or a hosted PWA/TWA approach.

BUILD ON GITHUB FROM AN ANDROID PHONE
1. Create a new GitHub repository named buhay-android (Private is fine).
2. Upload/extract ALL files and folders from this ZIP into the repository root. Keep the .github/workflows/build-apk.yml path.
3. Commit to the main branch.
4. Open repository > Actions > Build BUHAY APK > latest successful run.
5. Open Artifacts > BUHAY-debug-APK and download the ZIP. Extract app-debug.apk and install it.
6. If Android asks, allow installing unknown apps for the browser/file manager you used.

BUILD DETAILS
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- compileSdk 35
- minSdk 23
- Application ID: com.buhay.app

LIMITATIONS / REVIEW NOTES
- This environment cannot run the Android SDK build, so the APK must be built by GitHub Actions.
- The original app's Firestore and Realtime Database rules are retained unchanged. Review them before using real users/data.
- The original Firestore rules allow all authenticated users to read all user profile documents.
- Google sign-in popup behavior in embedded Android WebView is not verified and may fail.
- This is a wrapper of the existing web app, not a rewrite into native Kotlin screens.


BUHAY AUTH UPDATE (2026-11-18)
- Firebase Web config is populated for the existing project buhay-477bf.
- Android Google sign-in now uses the native Credential Manager bridge; web builds retain Firebase popup sign-in.
- Add `appassets.androidplatform.net` to Firebase Authentication > Settings > Authorized domains for the Web SDK.
- Before Google sign-in can work, replace app/src/main/res/values/strings.xml default_web_client_id with the Web application OAuth client ID from the same Firebase/Google Cloud project.
- The Android application ID is com.buhay.app. Add the SHA-1/SHA-256 of the signing certificate used for the installed APK to the Android app in Firebase, and confirm Google provider is enabled in Firebase Authentication.
- Email/password sign-in, Firestore, and Realtime Database still depend on the corresponding Firebase Authentication providers and security rules being enabled/deployed in Firebase Console.
- The app currently contains demo/local-only sections; this update does not convert every feed, media, calling, AI, or social feature into a production backend.
