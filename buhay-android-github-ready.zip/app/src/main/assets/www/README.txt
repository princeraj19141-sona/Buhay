BUHAY: deploy guide (simple steps, no coding)

PART 1: Firebase (one time, in browser: console.firebase.google.com)
 1. Add project > name it buhay > Create.
 2. Build > Authentication > Get started > turn ON Email/Password and Google.
 3. Build > Firestore Database > Create database > Production mode.
 4. Build > Realtime Database > Create database > Locked mode.
 5. Firestore Database > Rules tab: delete everything, paste the text from
    RULES-1-firestore-paste-in-console.txt, press Publish.
 6. Realtime Database > Rules tab: delete everything, paste the text from
    RULES-2-realtime-database-paste-in-console.txt, press Publish.
 7. Project settings (gear) > General > Your apps > Web (</>) > register app.
    Keep the firebaseConfig block open (you will copy it in Part 3).

PART 2: Netlify
 1. Open https://app.netlify.com/drop
 2. Drop this whole folder (all files inside it). You get a link like https://name.netlify.app
 3. Back in Firebase: Authentication > Settings > Authorized domains > Add domain:
    paste name.netlify.app (needed for Google login and reset emails).

PART 3: Connect the app (30 seconds, no file editing)
 1. Open your Netlify link on your phone.
 2. Welcome > Sign In > tap "Owner setup: connect Firebase".
 3. Paste the whole firebaseConfig block > Save and connect.
 4. Done. Sign up, chat. Settings > Connect Firebase > "Share setup link" connects another phone.

TIP: To make every visitor connect automatically, open firebase-config.js and paste your values
(replace the PASTE_ words) BEFORE Part 2. Or send the config to Claude and ask for a ready folder.

Install on phone: open the Netlify link in Chrome (Android) or Safari (iPhone) >
Settings > Install BUHAY on your phone, and follow the steps.
